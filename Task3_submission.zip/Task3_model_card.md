# Model Card: JurisCom RegTech — Jurisdiction-Aware AML/KYC Alert Engine
**Version:** 0.1.0-prototype  
**Date:** May 2026  
**Author:** Wong Joon Hoong (G2505242K) — JurisCom RegTech  
**Client Entity:** Standard Chartered Bank (SCB)  
**Jurisdictions covered:** United States (BSA/FinCEN), Singapore (MAS Notice 626)

---

## 1. Model Overview

### What this system does
This tool applies jurisdiction-specific AML/KYC rules from versioned JSON configuration files to individual transactions and customer records. It produces structured compliance alerts (CTR, CDD_ONE_OFF, SAR/STR, SANCTIONS_BLOCK, EDD_PEP, BO_FLAG) along with the rule reference, reason, and required action for each alert.

The core value proposition is the **jurisdiction configuration layer**: the same alert engine can serve multiple regulatory regimes by swapping the underlying JSON config — no code changes required.

### What this system is not
- Its filing logic is **not** a machine learning model. The notebook includes a small Isolation Forest + SHAP demonstration for anomaly explanation, but SAR/STR/CTR/CDD outcomes remain rules-based and examinable.
- It is **not** fully connected to live data sources. FX refreshes from a public online API into a versioned JSON cache with a freshness check; OFAC SDN and UN Consolidated sanctions XML refresh into a local cache; MAS TFS and regulatory text remain manual/static prototype inputs.
- It is **not** a case management system. It produces alert logs but does not route cases to reviewers, track dispositions, or manage the full SAR/STR filing workflow.

---

## 2. Intended Use

| Dimension | Details |
|---|---|
| **Intended users** | Bank compliance teams (CCOs, AML analysts); RegTech integration teams |
| **Intended deployment** | Pre-transaction screening and post-transaction monitoring; not real-time payment blocking |
| **Supported jurisdictions** | US (BSA/FinCEN) and Singapore (MAS Notice 626); other jurisdictions can be added by providing a conforming config JSON |
| **Out-of-scope uses** | Real-time payment blocking without human review; enforcement decision-making; retail-facing customer notifications |

---

## 3. Jurisdiction Configuration Layer

Each jurisdiction is encoded in a JSON file (e.g. `Task3_config/us_bsa_fincen.json`). The config specifies:

| Field group | Key parameters |
|---|---|
| `ctr` | US bank CTR threshold, applies_to transaction types, filing form and deadline; disabled for Singapore because MAS Notice 626 is not a US-style bank CTR regime |
| `non_account_cdd` | Singapore one-off transaction CDD threshold for customers without an existing business relationship |
| `str` | US SAR floor plus reason-to-suspect requirement; Singapore risk-based STR trigger with no fixed monetary threshold |
| `beneficial_ownership` | Percentage threshold, "bright_line" vs "reasonable_measures" standard |
| `pep` | Domestic PEP EDD required?, foreign PEP EDD required?, SM approval required? |
| `sanctions` | Program name, lists to screen against, fuzzy match threshold |
| `risk_levels` | Score ranges and review cycle by risk tier |
| `high_risk_countries` | ISO 3166-1 alpha-2 country codes |

**Config versioning:** Each JSON file carries `effective_date` and `last_updated` fields. Regulatory changes require a JSON update and version bump, not a code release.

---

## 4. Alert Types

| Alert type | Trigger logic | Jurisdiction difference |
|---|---|---|
| `CTR` | Same-day cumulative US cash/currency transaction >= USD 10,000 | US only in this prototype; no Singapore bank CTR analogue is encoded |
| `CDD_ONE_OFF` | Customer has no existing business relationship and transaction exceeds SGD 20,000 | Singapore MAS Notice 626 one-off CDD trigger |
| `SAR` | US only: transaction/aggregate >= USD 5,000 **and** reason to suspect (structuring, sanctions partial match, or explicit suspicion flag) | Prevents the prototype from treating amount alone as suspicious |
| `STR` | SG only: structuring, high-risk country, unusual pattern, partial sanctions match | No fixed threshold — purely risk-based |
| `SANCTIONS_BLOCK` | Customer or counterparty match on sanctions list | US: OFAC SDN; SG: MAS TFS + UN SC |
| `EDD_PEP` | PEP detected; EDD required per jurisdiction config | SG requires EDD for domestic PEPs; US does not |
| `BO_FLAG` | Corporate customer; beneficial ownership undisclosed | US: 25% bright-line — flag only if pct ≥ 25% AND undisclosed. SG: "reasonable measures" — flag whenever UBO information is *not on file*, with gradated severity: no info at all (escalate to MLRO), partial UBO known but undisclosed below 25% (document inquiry), or ≥25% undisclosed (collect certification). A corporate that has *disclosed* its ownership at <25% is **not** flagged under either standard — the bank has done the work. |

### Optional anomaly explanation layer
The notebook also trains an unsupervised Isolation Forest on the synthetic transaction features and uses SHAP to explain which features drove the most anomalous score. This layer is deliberately advisory: it can help an analyst prioritize review, but it does not replace the jurisdiction rule engine or create a filing obligation by itself.

### Sanctions source refresh
The project includes `Task3_sanctions_refresh.py`, which mirrors the FX staleness pattern for public sanctions sources. It refreshes and caches three sources:

| Source | File / status artifact | What is checked |
|---|---|---|
| OFAC SDN XML | `Task3_data/sanctions_cache/ofac_sdn.xml`; `Task3_data/sanctions_refresh_status.csv` | Download/fallback status, cache age, check/cache timestamps, OFAC publish date, record count, hash prefix |
| UN Security Council Consolidated XML | `Task3_data/sanctions_cache/un_consolidated.xml`; `Task3_data/sanctions_refresh_status.csv` | Download/fallback status, check/cache timestamps, generated date, individual/entity counts, hash prefix |
| MAS TFS landing page (best-effort scraper) | `Task3_data/sanctions_cache/mas_tfs_landing.html`; `Task3_data/sanctions_cache/mas_tfs_index.json`; `Task3_data/sanctions_cache/mas_tfs_index_last_good.json`; `Task3_data/sanctions_refresh_status.csv` | Weekly fetch of the MAS landing page, regex extraction of anchors mentioning sanctions/TFS/circulars/asset-freeze/UN-Security-Council, page-title diagnostic for maintenance/error windows, JS-render detection. Records counts of total anchors, sanctions-related anchors, PDF links, and dated entries. **Last-known-good fallback:** when a run captures >0 sanctions-related anchors, the payload is also written to `mas_tfs_index_last_good.json`; subsequent zero-entry runs (maintenance windows, layout changes) leave that file untouched and surface its age + entry count in the current run's `last_known_good` block and diagnostic string. PDF body parsing is **not** performed — designations themselves still require manual legal review or a licensed vendor feed |

The MAS scraper status field can be `OK`, `MAINTENANCE_PAGE_DETECTED` (page title contains "maintenance" / "error" / "service unavailable"), `PARTIAL_AUTOMATION` (page parsed but no sanctions anchors found, or page is JS-rendered with very few static anchors), or `STALE` (cache file older than the configured 7-day window). At the time of this submission the live MAS TFS page returned a maintenance template, which the scraper correctly flagged — this is the exact freshness signal the control exists to surface, and demonstrates why this layer is more useful than a fully manual process even though it does not parse PDF bodies.

**Fallback contract — last-known-good snapshot.** Every successful run that captures >0 sanctions-related anchors mirrors its payload into `Task3_data/sanctions_cache/mas_tfs_index_last_good.json`. Subsequent zero-entry runs leave that file untouched. The current `mas_tfs_index.json` carries a `last_known_good` block that records whether the baseline exists, when it was captured, its age in days, and its entry count. When a zero-entry run happens during a maintenance window or layout change, the diagnostic string in both the index and the status CSV's `note` column is appended with the last-known-good's age and entry count, so a reviewer can compare the present (broken) state against the most recent good capture. A clearly-marked seeded placeholder (`seeded: true`, `entry_count: 0`, no claimed entries) ships in the prototype because the live MAS landing page returned a maintenance template throughout the build window; the first successful >0-entry scrape will overwrite it.

This improves source freshness and auditability, but it does not turn the prototype into a full sanctions-screening engine. The transaction feed still contains upstream screening fields such as `is_sanctioned`, `sanctions_list_hit`, and `sanctions_match_score_pct`. Production use would still need name normalisation, alias logic, transliteration handling, false-positive workflow, list-delta approval, MAS-specific PDF ingestion (or a vendor feed such as Refinitiv World-Check, Dow Jones Risk Center, or ComplyAdvantage), and either a headless-browser pipeline or licensed XML feed for MAS designations themselves.

### Public enforcement scenario back-test
The verifier now exports `Task3_data/public_enforcement_backtest.csv`, a public-record scenario simulation based on SCB sanctions enforcement themes. This is not a replay of confidential historical transactions. It asks a narrower question: if the risk indicators were visible in transaction/customer fields, would this prototype surface the case for review?

| Public-record scenario | US result | SG result | Interpretation |
|---|---|---|---|
| Iran-linked USD clearing through the US | `SAR` | `STR` | Surfaces if Iran nexus remains visible in customer/payment fields |
| Myanmar/Burma sanctions-risk corridor | `SAR` | `SANCTIONS_BLOCK`, `STR` | SG lower fuzzy threshold creates a stronger review/blocking response |
| Syria blocked-party exposure | `SANCTIONS_BLOCK` | `SANCTIONS_BLOCK` | Direct list hits are caught by both configs |
| Sudan sanctions-risk payment | `SAR` | `STR` | Risk indicators trigger suspicious-transaction review |
| Zimbabwe SDN-owned party | `SANCTIONS_BLOCK`, `BO_FLAG` | `SANCTIONS_BLOCK`, `BO_FLAG` | List hit plus ownership opacity are visible controls |

The result is deliberately bounded. The tool would not detect SWIFT message stripping, hidden correspondent-bank information, or deliberately removed country identifiers unless those facts survive into the data feed. That is why Slide 12 treats SWIFT message integrity as a separate product boundary.

### SHAP interpretation
The SHAP summary plot shows that the strongest anomaly drivers in the synthetic dataset are `structuring_sg`, `structuring_us`, and `sanctions_match_pct`. In plain English, the model is mainly reacting to repeated below-threshold cash patterns and sanctions-screening proximity, which is consistent with the rules engine rather than a random statistical artefact.

The SHAP waterfall plot explains the most anomalous transaction, `TXN-US-005`. The top three contributors are `is_pep`, `sanctions_match_pct`, and `is_sanctioned`; together they explain why the transaction sits far away from ordinary behaviour. This is useful for analyst prioritisation, but it is not a filing decision: the legal alert still comes from the sanctions and PEP rule checks.

### Sensitivity and rules/ML coverage
The rules/ML coverage table is exported to `Task3_data/rules_ml_coverage.csv`: 29 transactions are rules-only, 0 are ML-only, and 7 are flagged by both rules and the Isolation Forest. In this small synthetic dataset, the ML layer confirms the high-risk rule alerts rather than discovering a separate typology; a real bank deployment would need larger behavioural history before claiming novel discovery.

`Task3_data/sensitivity_analysis.csv` shows that Isolation Forest contamination changes anomaly volume from 3 transactions at 0.05 to 9 at 0.20, while rules alerts remain 63. Structuring lookback is more operationally sensitive: a 3-day window produces 58 rule alerts, 5 days produces 60, and 7/14 days produce 63. This is exactly the kind of threshold tradeoff a bank model-risk or compliance team would review before production use.

---

## 5. Data Requirements

### Input data fields (minimum required)
- `txn_id`, `txn_type`, `amount_local`, `amount_usd`, `currency`, `same_day_cumulative_cash_usd`
- `is_pep`, `pep_type`, `is_sanctioned`, `sanctions_list_hit`
- `customer_type`, `beneficial_owner_pct`, `beneficial_owner_disclosed`
- `high_risk_country`, `counterparty_country`
- `computed_structuring_us`, `computed_structuring_sg`, `structuring_flag`, `unusual_pattern_notes`, `has_business_relationship`, `suspicious_activity_flag`

### Data quality assumptions
- Transaction amounts are accurate and in the stated currency
- FX refreshes from the configured online source into `fx_rates.json` for USD-equivalent dashboard values, then falls back to the cached JSON value if the API is unavailable; legally binding local-currency checks should still use `amount_local`
- OFAC SDN and UN Consolidated XML source files refresh into a local cache with daily staleness checks; MAS TFS remains a manual/PDF-limited source in this prototype
- PEP and transaction-level sanctions match flags are populated by an upstream screening service; the prototype freshness check does not itself perform production name matching
- Structuring detection is computed in the prototype using a 7-day rolling window over same-customer cash/currency transactions; production should extend this across related accounts and booking entities

### Data quality failure modes
| Failure | Effect | Mitigation |
|---|---|---|
| Stale or failed FX refresh | USD-equivalent comparison error for cross-jurisdiction dashboards; local-law threshold checks should use `amount_local` | Online refresh into `fx_rates.json`; alert if rate > 2 days old; prefer local-currency test for legal triggers |
| Missing sanctions flag | False negatives on sanctioned parties | Mandatory field; null = block transaction |
| Stale sanctions source cache | Screening may use old OFAC/UN list data | `Task3_sanctions_refresh.py` writes status/hash/date fields; stale source requires compliance review before relying on results |
| MAS TFS PDF/manual update missed | Singapore-specific TFS false negative | Document MAS TFS as manual/PDF-limited; production needs licensed/official feed or legal-ops update workflow |
| Incorrect customer_type | Beneficial ownership check skipped for misclassified corporates | Source system validation on ingestion |
| Missing transaction date/customer/amount fields | 7-day structuring detector may miss smurfing patterns | Make these fields mandatory and run aggregation before SAR/STR evaluation |
| Missing `has_business_relationship` | Singapore one-off CDD trigger may fire incorrectly | Make relationship status mandatory for non-account-holder transaction monitoring |

---

## 6. Known Failure Modes

### False Negatives (under-detection)
1. **Novel typologies** — rule-based engine cannot detect patterns not explicitly encoded. Examples not covered: trade-based money laundering (TBML) invoice manipulation, cryptocurrency-to-fiat layering, professional money laundering networks.
2. **Complex ownership chains** — the engine flags undisclosed BO but cannot trace multi-layer holding structures through BVI, Cayman, or VCC entities without upstream graph analysis.
3. **Threshold gaming across entities** — the prototype now computes 7-day rolling structuring within the available transaction feed, but it can still miss schemes split across related accounts, branches, or booking entities that are not linked in the data.

### False Positives (over-detection)
1. **High-risk country flag** — legitimate trade flows with FATF grey-list countries (e.g. Myanmar for garment exports) will trigger SG STRs. Volume of false positives depends on the bank's customer base.
2. **Partial sanctions matches** — common names or transliteration variants may produce false hits. Manual review is mandatory for all `SANCTIONS_BLOCK` alerts before action is taken.
3. **Domestic PEP EDD (SG)** — SG's broad PEP definition (includes family members and close associates) may over-flag retail customers with political connections.

### Performance drift
- The engine is rule-based and does not drift statistically. However, **regulatory drift** occurs when the underlying rules change and the JSON config is not updated. This is the primary operational risk.

### Multi-jurisdiction conflict (treated as a design choice, not a defect)
When a transaction has counterparties in both the US and Singapore, the prototype applies both configs independently and produces two parallel alert sets per transaction. The bank's written policy chooses the precedence rule. Three documented policy positions are described in the deck (Slide 11) and in Task 4 Q4: **booking-entity-wins** (default for cross-border banks), **most-restrictive-rule** (defensible during enforcement-heat periods), and **counterparty-touches** (useful for SG risk-based STR on US-booked transactions to FATF high-risk countries). The tool deliberately does not hard-code the resolution because the choice is bank-specific policy and a vendor-imposed default could be read by an examiner as the bank ceding judgement.

---

## 7. Human Oversight Requirements

**No alert should result in a customer action without human review.** Specifically:

| Alert type | Human review required? | Who reviews? |
|---|---|---|
| `SANCTIONS_BLOCK` | Yes — before transaction is permanently blocked | Senior AML analyst + Compliance |
| `CTR` | No — US filing is mandatory once threshold met | Technology (auto-file); Compliance spot-checks |
| `CDD_ONE_OFF` | Yes — identity verification and recordkeeping require operational completion | KYC analyst |
| `SAR` / `STR` | Yes — decision to file is a human judgement | AML analyst; escalation to Compliance for borderline cases |
| `EDD_PEP` | Yes — EDD process is human-led | Relationship Manager + Compliance |
| `BO_FLAG` | Yes — document reasonable measures | KYC analyst |

---

## 8. Regulatory References

### United States
- Bank Secrecy Act, 31 U.S.C. § 5311 et seq.
- 31 CFR 1010.311 (Currency Transaction Reports)
- 31 CFR 1020.320 (Reports by banks of suspicious transactions)
- FinCEN Form 111 (Suspicious Activity Report)
- FinCEN Form 112 (Currency Transaction Report)
- FinCEN Customer Due Diligence Rule, 31 CFR § 1010.230 (effective May 2018)
- USA PATRIOT Act, Section 312 (foreign correspondent and private banking accounts)
- FinCEN Guidance FIN-2008-G005 (PEP guidance)

### Singapore
- Corruption, Drug Trafficking and Other Serious Crimes (Confiscation of Benefits) Act (CDSA), Cap. 65A
- Terrorism (Suppression of Financing) Act (TSOFA), Cap. 325
- MAS Notice 626 — Prevention of Money Laundering and Countering the Financing of Terrorism (Banks); prototype config reviewed May 2026
- MAS Notice 626 Annex 1B — PEP definitions
- MAS Targeted Financial Sanctions Guidance (2023)
- Variable Capital Companies Act 2018 (beneficial ownership for VCCs)

### Public enforcement sources used for scenario back-test
- OFAC, "Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control and Standard Chartered Bank" (9 April 2019): https://ofac.treasury.gov/recent-actions/20190409
- U.S. Treasury, "U.S. Treasury Department Announces Settlement with Standard Chartered Bank" (9 April 2019): https://home.treasury.gov/news/press-releases/sm647
- U.S. Department of Justice, "Standard Chartered Bank Admits to Illegally Processing Transactions in Violation of Iranian Sanctions and Agrees to Pay More Than $1 Billion" (9 April 2019): https://www.justice.gov/usao-dc/pr/standard-chartered-bank-admits-illegally-processing-transactions-violation-iranian

### Sanctions data-source references
- OFAC Sanctions List Service: https://ofac.treasury.gov/sanctions-list-service
- OFAC SDN XML bulk file: https://www.treasury.gov/ofac/downloads/sdn.xml
- UN Security Council Consolidated List: https://main.un.org/securitycouncil/en/content/un-sc-consolidated-list
- UN Consolidated XML bulk file: https://scsanctions.un.org/resources/xml/en/consolidated.xml
- MAS Targeted Financial Sanctions page: https://www.mas.gov.sg/regulation/anti-money-laundering/targeted-financial-sanctions

---

## 9. What Was Not Built (and Why)

| Feature | Reason not included |
|---|---|
| Production ML anomaly scoring | Prototype includes an Isolation Forest + SHAP demonstration, but production use would require historical data, validation, monitoring, and a policy for how anomaly scores affect review priority |
| Production sanctions screening | Public OFAC/UN XML refresh exists; MAS TFS now has a best-effort landing-page scraper with maintenance/JS-render diagnostics. Still missing: production name matching, MAS PDF body parsing or licensed vendor feed (Refinitiv / Dow Jones / ComplyAdvantage), delta approval, false-positive workflow, and vendor-grade audit controls |
| Multi-jurisdiction conflict resolution logic | Requires bank-specific policy decision on which jurisdiction's rules take precedence |
| Case management workflow | Out of scope; would require a database, UI, and user authentication layer |
| Risk scoring model (0–100) | Partially sketched in config `risk_levels` but not implemented in alert engine — requires additional risk factor inputs |
| Regulatory change notifications | Would require a subscription to regulatory RSS feeds or legal update services |

---

## 10. Contact and Governance

| Role | Name | Responsibility |
|---|---|---|
| Model Owner | JurisCom RegTech Product Team | Config versioning, feature roadmap |
| Compliance Liaison | Standard Chartered Bank CCO Office | Regulatory interpretation, alert disposition policy |
| Technology Owner | JurisCom Engineering | Code maintenance, data pipeline |
| Annual Reviewer | JurisCom Legal + Compliance | Full config audit against regulatory text |
