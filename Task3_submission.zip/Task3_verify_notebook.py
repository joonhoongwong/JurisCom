"""
Standalone verification script for the Task 3 notebook.

Runs the rules engine + structuring detector + isolation-forest anomaly layer,
writes generated artifacts, and verifies the differential and trigger cases.
"""
import json
import urllib.request
import warnings
from dataclasses import dataclass, asdict
from datetime import date
from pathlib import Path

import pandas as pd

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except ModuleNotFoundError:
    plt = None

# Silence only the noisy third-party warnings that have no compliance signal.
# A reviewer should still see pandas / sklearn deprecation warnings if they fire.
warnings.filterwarnings("ignore", category=UserWarning, module="shap")
warnings.filterwarnings("ignore", category=FutureWarning, module="shap")

BASE_DIR = Path(__file__).parent if "__file__" in globals() else Path.cwd()
CONFIG_DIR = BASE_DIR / "Task3_config"
DATA_DIR = BASE_DIR / "Task3_data"


with open(CONFIG_DIR / "us_bsa_fincen.json", encoding="utf-8") as f:
    US_CONFIG = json.load(f)
with open(CONFIG_DIR / "sg_mas_notice626.json", encoding="utf-8") as f:
    SG_CONFIG = json.load(f)


FX_STATUS = []


def refresh_sgd_usd_from_api(sgd_usd_cfg: dict) -> tuple[float, str, str, str] | None:
    """Refresh SGD/USD from a public online FX API.

    MAS is the preferred production source for Singapore regulatory use, but
    its public portal is not always available for scripted access. For this
    academic prototype, the online refresh uses Frankfurter's no-key public API
    and keeps the JSON file as a local cache/fallback.
    """

    refresh_cfg = sgd_usd_cfg.get("online_refresh", {})
    if not refresh_cfg.get("enabled", True):
        return None

    url = refresh_cfg.get("url", "https://api.frankfurter.dev/v2/rate/SGD/USD")
    source_name = refresh_cfg.get("source_name", "Frankfurter public FX API")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "JurisCom-RegTech-Prototype/0.1"})
        with urllib.request.urlopen(req, timeout=15) as response:
            payload = json.loads(response.read().decode("utf-8"))
        rate = float(payload["rate"])
        rate_date = str(payload.get("date") or date.today().isoformat())
        return rate, rate_date, source_name, url
    except Exception as exc:
        print(f"Online FX refresh failed ({exc}); using cached fx_rates.json value")
        return None


def apply_fx_rates() -> None:
    """Load FX from online API/cache and emit a stale-rate status artifact.

    Legal thresholds are still tested in local currency where possible. The FX
    layer exists so cross-jurisdiction dashboards and USD-denominated examples
    do not silently rely on an undocumented hardcoded number.
    """

    fx_path = CONFIG_DIR / "fx_rates.json"
    if not fx_path.exists():
        print("fx_rates.json not found; using jurisdiction-config USD equivalents")
        return

    with open(fx_path, encoding="utf-8") as f:
        fx_cfg = json.load(f)

    sgd_usd = fx_cfg.get("SGD_USD", {})
    refresh = refresh_sgd_usd_from_api(sgd_usd)
    source_name = sgd_usd.get("source", "Cached fx_rates.json")
    source_url = sgd_usd.get("source_url", "")
    refresh_mode = "cache"
    if refresh is not None:
        rate, last_updated, source_name, source_url = refresh
        sgd_usd["rate"] = rate
        sgd_usd["last_updated"] = last_updated
        sgd_usd["last_refreshed"] = date.today().isoformat()
        sgd_usd["source"] = source_name
        sgd_usd["source_url"] = source_url
        fx_cfg["SGD_USD"] = sgd_usd
        fx_path.write_text(json.dumps(fx_cfg, indent=2), encoding="utf-8")
        refresh_mode = "online"

    rate = float(sgd_usd.get("rate", SG_CONFIG.get("fx_rate_to_usd", 0.743)))
    last_updated = sgd_usd.get("last_updated", "")
    stale_after_days = int(sgd_usd.get("stale_after_days", 2))
    age_days = None
    stale = False
    if last_updated:
        age_days = (date.today() - date.fromisoformat(last_updated)).days
        stale = age_days > stale_after_days

    SG_CONFIG["fx_rate_to_usd"] = rate
    if SG_CONFIG.get("non_account_cdd", {}).get("threshold_local"):
        SG_CONFIG["non_account_cdd"]["threshold_usd"] = round(
            float(SG_CONFIG["non_account_cdd"]["threshold_local"]) * rate
        )

    FX_STATUS.append({
        "pair": "SGD_USD",
        "rate": rate,
        "last_updated": last_updated,
        "age_days": age_days,
        "stale_after_days": stale_after_days,
        "status": "STALE" if stale else "OK",
        "refresh_mode": refresh_mode,
        "source": source_name,
        "source_url": source_url,
        "note": "Refresh FX before relying on USD-equivalent dashboard values" if stale else "FX snapshot within prototype freshness window",
    })
    print(
        f"FX SGD/USD={rate}; last_updated={last_updated}; "
        f"status={'STALE' if stale else 'OK'}; source={refresh_mode}"
    )


apply_fx_rates()


def load_transactions() -> pd.DataFrame:
    df = pd.read_csv(DATA_DIR / "synthetic_transactions.csv", dtype=str)
    for col in [
        "amount_local",
        "amount_usd",
        "same_day_cumulative_cash_usd",
        "beneficial_owner_pct",
        "sanctions_match_score_pct",
    ]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    for col in [
        "is_pep",
        "is_sanctioned",
        "high_risk_country",
        "beneficial_owner_disclosed",
        "structuring_flag",
        "has_business_relationship",
        "suspicious_activity_flag",
    ]:
        df[col] = (
            df[col]
            .str.strip()
            .str.lower()
            .map({"true": True, "false": False})
            .fillna(False)
        )
    return df


df = load_transactions()
print(f"Loaded {len(df)} transactions. Configs: {US_CONFIG['jurisdiction']}, {SG_CONFIG['jurisdiction']}")


@dataclass
class AlertResult:
    txn_id: str
    jurisdiction: str
    alert_type: str
    triggered: bool
    reason: str
    rule_ref: str
    action_required: str
    filing_deadline: str = ""


class JurisdictionAlertEngine:
    def __init__(self, config: dict):
        self.cfg = config
        self.jur = config["jurisdiction"]
        self.structuring_col = f"computed_structuring_{self.jur.lower()}"

    def evaluate(self, txn: dict) -> list[AlertResult]:
        alerts = (
            self._check_sanctions(txn)
            + self._check_ctr(txn)
            + self._check_non_account_cdd(txn)
            + self._check_str_sar(txn)
            + self._check_pep(txn)
            + self._check_beneficial_ownership(txn)
        )
        return [a for a in alerts if a.triggered]

    def _check_sanctions(self, txn: dict) -> list[AlertResult]:
        hit = str(txn.get("sanctions_list_hit", "none")).strip().lower()
        score = float(txn.get("sanctions_match_score_pct", 0) or 0)
        sanctions = self.cfg["sanctions"]
        threshold = float(sanctions.get("match_threshold_pct", 100))
        exact_hit_labels = {"sdn", "mas_tfs", "un_tfs", "ofac_sdn", "un_designated"}
        exact_hit = txn["is_sanctioned"] or hit in exact_hit_labels
        fuzzy_hit = score >= threshold
        if exact_hit or fuzzy_hit:
            reasons = []
            if exact_hit:
                reasons.append(f"list hit: {hit}")
            if score:
                reasons.append(f"match score {score:,.0f}% >= threshold {threshold:,.0f}%")
            return [
                AlertResult(
                    txn["txn_id"],
                    self.jur,
                    "SANCTIONS_BLOCK",
                    True,
                    "; ".join(reasons),
                    f"{self.cfg['regulation']} sanctions program",
                    "BLOCK + file STR/SAR; escalate",
                )
            ]
        return []

    def _check_ctr(self, txn: dict) -> list[AlertResult]:
        ctr = self.cfg["ctr"]
        if not ctr.get("enabled", True) or ctr.get("threshold_usd") is None:
            return []
        if txn["txn_type"] not in ctr["applies_to"]:
            return []
        cumulative_usd = float(txn["same_day_cumulative_cash_usd"])
        if cumulative_usd >= ctr["threshold_usd"]:
            return [
                AlertResult(
                    txn["txn_id"],
                    self.jur,
                    ctr["abbreviation"],
                    True,
                    f"USD {cumulative_usd:,.0f} >= threshold {ctr['threshold_usd']:,}",
                    f"{self.cfg['regulation']} - {ctr['form']}",
                    f"File {ctr['abbreviation']} within {ctr['filing_deadline_days']} days",
                    f"{ctr['filing_deadline_days']} calendar days",
                )
            ]
        return []

    def _check_non_account_cdd(self, txn: dict) -> list[AlertResult]:
        cdd = self.cfg.get("non_account_cdd", {})
        if not cdd.get("enabled"):
            return []
        if bool(txn.get("has_business_relationship", True)):
            return []
        if txn["txn_type"] not in cdd["applies_to"]:
            return []

        if str(txn["currency"]).upper() == str(self.cfg["currency"]).upper():
            value = float(txn["amount_local"])
            threshold = float(cdd["threshold_local"])
            label = f"{self.cfg['currency']} {value:,.0f} >= threshold {threshold:,.0f}"
        else:
            value = float(txn["amount_usd"])
            threshold = float(cdd["threshold_usd"])
            label = f"USD {value:,.0f} >= threshold {threshold:,.0f}"

        if value >= threshold:
            return [
                AlertResult(
                    txn["txn_id"],
                    self.jur,
                    cdd["abbreviation"],
                    True,
                    label,
                    cdd["rule_ref"],
                    "Perform and document CDD for non-account-holder transaction",
                )
            ]
        return []

    def _check_str_sar(self, txn: dict) -> list[AlertResult]:
        sc = self.cfg["str"]
        amount_usd = float(txn["amount_usd"])
        aggregate_usd = float(txn["same_day_cumulative_cash_usd"])
        structuring = bool(txn.get(self.structuring_col, txn.get("structuring_flag", False)))
        high_risk = bool(txn["high_risk_country"])
        unusual = str(txn.get("unusual_pattern_notes", "")).strip().lower()
        unusual = "" if unusual == "none" else unusual
        hit = str(txn.get("sanctions_list_hit", "none")).strip().lower()
        score = float(txn.get("sanctions_match_score_pct", 0) or 0)
        partial_sanctions_match = hit not in ["", "none"] or score > 0

        # Full sanctions hits are handled by the blocking check above.
        if txn["is_sanctioned"]:
            return []

        if sc["no_fixed_threshold"]:
            reasons = []
            if structuring:
                reasons.append("structuring pattern")
            if high_risk:
                reasons.append(f"high-risk country ({txn['counterparty_country']})")
            if partial_sanctions_match:
                reasons.append("sanctions partial/fuzzy match")
            if unusual:
                reasons.append(unusual)
            if reasons:
                return [
                    AlertResult(
                        txn["txn_id"],
                        self.jur,
                        "STR",
                        True,
                        f"Risk-based STR: {'; '.join(reasons)}",
                        f"{self.cfg['regulation']} - STR ({sc['regulator']})",
                        "File STR with STRO as soon as practicable; no tipping off",
                    )
                ]
        else:
            threshold = sc["threshold_usd"]
            sar_amount = max(amount_usd, aggregate_usd)
            reasons = []
            if structuring:
                reasons.append("structuring pattern")
            if partial_sanctions_match:
                reasons.append("sanctions partial/fuzzy match")
            if bool(txn.get("suspicious_activity_flag", False)):
                reasons.append(unusual or "reason to suspect")
            if sar_amount >= threshold and reasons:
                return [
                    AlertResult(
                        txn["txn_id"],
                        self.jur,
                        "SAR",
                        True,
                        f"USD {sar_amount:,.0f} >= SAR floor {threshold:,}; " + "; ".join(reasons),
                        f"{self.cfg['regulation']} - SAR ({sc['rule_ref']})",
                        f"File SAR with FinCEN within {sc['filing_deadline_days']} days",
                        f"{sc['filing_deadline_days']} calendar days",
                    )
                ]
        return []

    def _check_pep(self, txn: dict) -> list[AlertResult]:
        pep = self.cfg["pep"]
        pep_type = str(txn.get("pep_type", "none")).strip().lower()
        if pep_type == "none":
            return []
        domestic = pep_type == "domestic"
        if (domestic and pep["domestic_pep_enhanced_dd"]) or (
            not domestic and pep["foreign_pep_enhanced_dd"]
        ):
            extras = []
            if pep.get("senior_management_approval_required"):
                extras.append("SM approval required")
            if pep.get("source_of_wealth_required"):
                extras.append("source of wealth required")
            return [
                AlertResult(
                    txn["txn_id"],
                    self.jur,
                    "EDD_PEP",
                    True,
                    f"{pep_type.upper()} PEP - EDD required"
                    + (("; " + "; ".join(extras)) if extras else ""),
                    self.cfg["regulation"],
                    "Initiate EDD; collect source of wealth",
                )
            ]
        return []

    def _check_beneficial_ownership(self, txn: dict) -> list[AlertResult]:
        """Beneficial-ownership flag with jurisdiction-specific standard.

        Three regulatory states a corporate customer can be in:
          1. UBO disclosed at >= threshold pct  --> NO flag (control satisfied)
          2. UBO disclosed at <  threshold pct  --> NO flag under bright-line;
             NO flag under reasonable_measures *if* the bank has on-file evidence
             of the disclosed pct (we model "disclosed=True" as that evidence).
          3. UBO not disclosed at all (no evidence on file) --> flag, with
             severity gradated by what the bank does/does not know:
               - 'no_info' (pct == 0): high concern, escalate
               - 'partial_undisclosed' (pct > 0 & < threshold): medium concern, investigate
               - 'above_threshold_undisclosed' (pct >= threshold): always flag in both standards

        US 31 CFR 1010.230 is bright-line: case (3c) only.
        SG MAS Notice 626 Para 6.2 'reasonable measures': cases (3a), (3b), (3c).
        Case (2) is NOT flagged under either standard — the bank has done the work.
        """
        if txn["customer_type"] != "corporate":
            return []
        bo = self.cfg["beneficial_ownership"]
        disclosed = bool(txn["beneficial_owner_disclosed"])
        pct = float(txn["beneficial_owner_pct"])
        threshold = bo["threshold_pct"]
        standard = bo["standard"]

        # State (1) and (2): UBO information on file --> no flag
        if disclosed:
            return []

        # State (3c): undisclosed UBO above threshold --> always flag in both standards
        if pct >= threshold:
            return [
                AlertResult(
                    txn["txn_id"], self.jur, "BO_FLAG", True,
                    f"UBO {pct}% >= {threshold}% threshold; not disclosed",
                    bo["rule_ref"],
                    "Collect BO certification before further activity",
                )
            ]

        # bright_line stops here: <threshold + undisclosed = no flag under US 31 CFR 1010.230
        if standard == "bright_line":
            return []

        # reasonable_measures: split (3a) and (3b) for proportionate action
        if pct == 0:
            # State (3a): no UBO information at all - high concern
            return [
                AlertResult(
                    txn["txn_id"], self.jur, "BO_FLAG", True,
                    "No UBO information on file; reasonable-measures inquiry required",
                    bo["rule_ref"],
                    "Escalate to MLRO; document inquiry; consider relationship suspension if UBO unidentifiable",
                )
            ]
        # State (3b): partial UBO known but undisclosed below threshold
        return [
            AlertResult(
                txn["txn_id"], self.jur, "BO_FLAG", True,
                f"Partial UBO ({pct}%) below {threshold}% threshold and undisclosed; reasonable-measures inquiry required",
                bo["rule_ref"],
                "Document reasonable measures taken; record residual unknown ownership",
            )
        ]


class StructuringDetector:
    """Rolling-window structuring detection.

    For a given jurisdiction, finds cash transactions where each individual
    amount is below the local threshold but the rolling-window sum per
    customer reaches it. Flags every contributing transaction.
    """

    def __init__(self, jurisdiction_cfg: dict, lookback_days: int | None = None):
        self.cfg = jurisdiction_cfg
        self.currency = jurisdiction_cfg.get("currency", "")
        ctr = jurisdiction_cfg.get("ctr", {}) or {}
        cdd = jurisdiction_cfg.get("non_account_cdd", {}) or {}
        if ctr.get("enabled", True) and ctr.get("threshold_local"):
            src = ctr
        elif cdd.get("enabled"):
            src = cdd
        else:
            src = {}
        self.threshold_local = float(src.get("threshold_local") or 0)
        # Assignment upgrade: use a rolling 7-day aggregator rather than a
        # manually supplied structuring flag. This is intentionally constant
        # across jurisdictions for prototype comparability.
        self.lookback_days = int(lookback_days or 7)
        self.min_txns = int(src.get("structuring_min_txns_in_window") or 3)
        self.applies_to = set(src.get("applies_to") or [])

    def detect(self, df: pd.DataFrame) -> pd.Series:
        flags = pd.Series(False, index=df.index)
        if self.threshold_local <= 0 or not self.applies_to:
            return flags
        mask = (
            df["txn_type"].isin(self.applies_to)
            & (df["currency"].astype(str).str.upper() == str(self.currency).upper())
            & (df["amount_local"].astype(float) < self.threshold_local)
        )
        cash = df.loc[mask].copy()
        if cash.empty:
            return flags
        cash["_d"] = pd.to_datetime(cash["txn_date"])
        cash["_amt"] = cash["amount_local"].astype(float)
        for _, group in cash.groupby("customer_id"):
            group = group.sort_values("_d")
            dates = group["_d"].values
            amounts = group["_amt"].values
            indices = group.index.values
            for i in range(len(group)):
                window_end = dates[i]
                window_start = window_end - pd.Timedelta(days=self.lookback_days - 1)
                in_window = (dates >= window_start) & (dates <= window_end)
                if in_window.sum() >= self.min_txns and amounts[in_window].sum() >= self.threshold_local:
                    for idx in indices[in_window]:
                        flags.loc[idx] = True
        return flags


df["computed_structuring_us"] = StructuringDetector(US_CONFIG).detect(df)
df["computed_structuring_sg"] = StructuringDetector(SG_CONFIG).detect(df)
print(
    "Computed structuring flags: "
    f"US={int(df['computed_structuring_us'].sum())}, "
    f"SG={int(df['computed_structuring_sg'].sum())}"
)
pd.DataFrame(FX_STATUS).to_csv(DATA_DIR / "fx_rate_status.csv", index=False)
print(f"fx_rate_status.csv written: {(DATA_DIR / 'fx_rate_status.csv').exists()}")

us_engine = JurisdictionAlertEngine(US_CONFIG)
sg_engine = JurisdictionAlertEngine(SG_CONFIG)


def collect_alert_rows(input_df: pd.DataFrame) -> list[dict]:
    rows = []
    for _, row in input_df.iterrows():
        txn = row.to_dict()
        for alert in us_engine.evaluate(txn):
            rows.append({**asdict(alert), "config_applied": "US_BSA_FinCEN"})
        for alert in sg_engine.evaluate(txn):
            rows.append({**asdict(alert), "config_applied": "SG_MAS_Notice626"})
    return rows


results = collect_alert_rows(df)

alerts_df = pd.DataFrame(results)
print(f"\nTotal alerts triggered: {len(alerts_df)}")
print(alerts_df.groupby(["config_applied", "alert_type"]).size().unstack(fill_value=0))

alerts_df.to_csv(DATA_DIR / "alert_results.csv", index=False)
print(f"\nalert_results.csv written: {(DATA_DIR / 'alert_results.csv').exists()}")


PUBLIC_ENFORCEMENT_SOURCES = {
    "OFAC_SC_B_2019": "https://ofac.treasury.gov/recent-actions/20190409",
    "TREASURY_SC_B_2019": "https://home.treasury.gov/news/press-releases/sm647",
    "DOJ_SC_B_2019": "https://www.justice.gov/usao-dc/pr/standard-chartered-bank-admits-illegally-processing-transactions-violation-iranian",
}


def public_enforcement_scenario_rows() -> list[dict]:
    """Public-record scenario simulation, not historical transaction replay."""

    base = {
        "txn_date": "2024-12-31",
        "txn_type": "wire_transfer",
        "currency": "USD",
        "beneficial_owner_pct": 0.0,
        "beneficial_owner_disclosed": True,
        "country_of_origin": "SG",
        "has_business_relationship": True,
        "same_day_cumulative_cash_usd": 0.0,
        "structuring_flag": False,
        "computed_structuring_us": False,
        "computed_structuring_sg": False,
        "is_pep": False,
        "pep_type": "none",
    }
    return [
        {
            **base,
            "txn_id": "PUB-SCB-IR-001",
            "scenario_country": "Iran",
            "public_record_pattern": "Iran-linked Dubai customer using USD clearing through the United States",
            "booking_entity": "SCB_DUBAI",
            "amount_local": 75000,
            "amount_usd": 75000,
            "customer_id": "PUB-IR-001",
            "customer_name": "Iran Nexus General Trading",
            "customer_type": "corporate",
            "customer_risk_rating": "high",
            "is_sanctioned": False,
            "sanctions_list_hit": "Iran_nexus_review",
            "sanctions_match_score_pct": 70,
            "high_risk_country": True,
            "counterparty_name": "Tehran Industrial Supplies",
            "counterparty_country": "IR",
            "unusual_pattern_notes": "Public-record scenario: Iran nexus visible in payment/customer fields",
            "purpose_of_txn": "trade_settlement",
            "suspicious_activity_flag": True,
            "source_url": PUBLIC_ENFORCEMENT_SOURCES["DOJ_SC_B_2019"],
            "limitation_note": "Would surface only if Iran nexus is visible; stripped SWIFT fields require separate message-integrity controls.",
        },
        {
            **base,
            "txn_id": "PUB-SCB-MM-001",
            "scenario_country": "Myanmar/Burma",
            "public_record_pattern": "Burma/Myanmar sanctions-risk payment routed through US dollar clearing",
            "booking_entity": "SCB_SG",
            "amount_local": 42000,
            "amount_usd": 42000,
            "customer_id": "PUB-MM-001",
            "customer_name": "Mandalay Corridor Trading",
            "customer_type": "corporate",
            "customer_risk_rating": "high",
            "is_sanctioned": False,
            "sanctions_list_hit": "name_similarity_review",
            "sanctions_match_score_pct": 83,
            "high_risk_country": True,
            "counterparty_name": "Yangon Logistics Co",
            "counterparty_country": "MM",
            "unusual_pattern_notes": "Public-record scenario: Myanmar/Burma sanctions-risk corridor",
            "purpose_of_txn": "trade_finance",
            "suspicious_activity_flag": True,
            "source_url": PUBLIC_ENFORCEMENT_SOURCES["TREASURY_SC_B_2019"],
            "limitation_note": "Would create sanctions/STR review if country and fuzzy-screening fields are present.",
        },
        {
            **base,
            "txn_id": "PUB-SCB-SY-001",
            "scenario_country": "Syria",
            "public_record_pattern": "Syria sanctions-program exposure through a blocked counterparty",
            "booking_entity": "SCB_SG",
            "amount_local": 65000,
            "amount_usd": 65000,
            "customer_id": "PUB-SY-001",
            "customer_name": "Levant Import Services",
            "customer_type": "corporate",
            "customer_risk_rating": "high",
            "is_sanctioned": True,
            "sanctions_list_hit": "SDN",
            "sanctions_match_score_pct": 100,
            "high_risk_country": True,
            "counterparty_name": "Damascus Procurement Office",
            "counterparty_country": "SY",
            "unusual_pattern_notes": "Public-record scenario: Syria blocked-party exposure",
            "purpose_of_txn": "supplier_payment",
            "suspicious_activity_flag": True,
            "source_url": PUBLIC_ENFORCEMENT_SOURCES["OFAC_SC_B_2019"],
            "limitation_note": "Would block if the party/list hit is visible to screening.",
        },
        {
            **base,
            "txn_id": "PUB-SCB-SD-001",
            "scenario_country": "Sudan",
            "public_record_pattern": "Sudan sanctions-risk USD transaction through the US financial system",
            "booking_entity": "SCB_DUBAI",
            "amount_local": 38000,
            "amount_usd": 38000,
            "customer_id": "PUB-SD-001",
            "customer_name": "Red Sea Commodity Traders",
            "customer_type": "corporate",
            "customer_risk_rating": "high",
            "is_sanctioned": False,
            "sanctions_list_hit": "Sudan_program_review",
            "sanctions_match_score_pct": 72,
            "high_risk_country": True,
            "counterparty_name": "Khartoum Trade Bureau",
            "counterparty_country": "SD",
            "unusual_pattern_notes": "Public-record scenario: Sudan sanctions-risk payment",
            "purpose_of_txn": "trade_settlement",
            "suspicious_activity_flag": True,
            "source_url": PUBLIC_ENFORCEMENT_SOURCES["OFAC_SC_B_2019"],
            "limitation_note": "Would surface as SAR/STR review if country/program indicators survive ingestion.",
        },
        {
            **base,
            "txn_id": "PUB-SCB-ZW-001",
            "scenario_country": "Zimbabwe",
            "public_record_pattern": "Zimbabwe SDN-owned party with US-dollar settlement exposure",
            "booking_entity": "SCB_ZW",
            "amount_local": 51000,
            "amount_usd": 51000,
            "customer_id": "PUB-ZW-001",
            "customer_name": "Harare Holdings Ltd",
            "customer_type": "corporate",
            "customer_risk_rating": "high",
            "is_sanctioned": True,
            "sanctions_list_hit": "SDN",
            "sanctions_match_score_pct": 100,
            "beneficial_owner_pct": 50.0,
            "beneficial_owner_disclosed": False,
            "high_risk_country": True,
            "counterparty_name": "Zimbabwe SDN-Owned Entity",
            "counterparty_country": "ZW",
            "unusual_pattern_notes": "Public-record scenario: SDN or 50-percent-rule ownership exposure",
            "purpose_of_txn": "card_settlement",
            "suspicious_activity_flag": True,
            "source_url": PUBLIC_ENFORCEMENT_SOURCES["OFAC_SC_B_2019"],
            "limitation_note": "Would block on SDN hit and flag beneficial ownership opacity if ownership data is available.",
        },
    ]


enforcement_rows = []
for scenario in public_enforcement_scenario_rows():
    for jurisdiction, engine in [("US", us_engine), ("SG", sg_engine)]:
        scenario_alerts = engine.evaluate(scenario)
        enforcement_rows.append({
            "scenario_id": scenario["txn_id"],
            "scenario_country": scenario["scenario_country"],
            "jurisdiction_tested": jurisdiction,
            "public_record_pattern": scenario["public_record_pattern"],
            "alert_types": ";".join(a.alert_type for a in scenario_alerts) or "NONE",
            "alert_count": len(scenario_alerts),
            "surfaced_by_tool": bool(scenario_alerts),
            "tool_response": " | ".join(a.reason for a in scenario_alerts) or "No alert",
            "limitation_note": scenario["limitation_note"],
            "source_url": scenario["source_url"],
        })

enforcement_df = pd.DataFrame(enforcement_rows)
enforcement_df.to_csv(DATA_DIR / "public_enforcement_backtest.csv", index=False)
print(f"public_enforcement_backtest.csv written: {(DATA_DIR / 'public_enforcement_backtest.csv').exists()}")


US_C, SG_C = "#1f4e79", "#c00000"
alert_counts = alerts_df.groupby(["config_applied", "alert_type"]).size().unstack(fill_value=0)
alert_counts = alert_counts.reindex(["US_BSA_FinCEN", "SG_MAS_Notice626"]).fillna(0)
labels = ["US CTR\n(bank currency txn)", "SG one-off CDD\n(non-account holder)"]
thresholds = [
    US_CONFIG["ctr"]["threshold_usd"],
    SG_CONFIG["non_account_cdd"]["threshold_usd"],
]

if plt is not None:
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    fig.suptitle(
        "JurisCom RegTech - AML/KYC Alert Analysis\nStandard Chartered Bank (US vs Singapore)",
        fontsize=13,
        fontweight="bold",
    )
    alert_counts.T.plot(kind="bar", ax=axes[0], color=[US_C, SG_C], edgecolor="white", width=0.6)
    axes[0].set_title("Alert Type Distribution by Jurisdiction", fontsize=11)
    axes[0].set_xlabel("Alert Type")
    axes[0].set_ylabel("Number of Alerts")
    axes[0].legend(["US BSA/FinCEN", "SG MAS Notice 626"])
    axes[0].tick_params(axis="x", rotation=30)
    axes[0].grid(axis="y", alpha=0.3)

    bars = axes[1].bar(range(2), thresholds, color=[US_C, SG_C], width=0.5, edgecolor="white")
    for bar, value in zip(bars, thresholds):
        axes[1].text(bar.get_x() + bar.get_width() / 2, value + 250, f"${value:,.0f}", ha="center", fontsize=9)
    axes[1].axhline(y=US_CONFIG["str"]["threshold_usd"], color="orange", linestyle="--", linewidth=1.5, label="US SAR floor ($5,000 + suspicion)")
    axes[1].text(
        1,
        1000,
        "SG STR: no fixed\nthreshold\n(risk-based)",
        ha="center",
        color=SG_C,
        fontsize=9,
        bbox=dict(boxstyle="round,pad=0.3", facecolor="#ffe0e0", alpha=0.7),
    )
    axes[1].set_xticks([0, 1])
    axes[1].set_xticklabels(labels)
    axes[1].set_title("Selected AML/KYC Thresholds (USD Equivalent)")
    axes[1].set_ylabel("USD")
    axes[1].legend(fontsize=8, loc="upper left")
    axes[1].grid(axis="y", alpha=0.3)
    axes[1].set_ylim(0, 30000)
    plt.tight_layout()
    plt.savefig(DATA_DIR / "threshold_comparison.png", dpi=150, bbox_inches="tight")
    plt.close()
else:
    from PIL import Image, ImageDraw, ImageFont

    def get_font(size: int, bold: bool = False):
        candidates = [
            r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf",
            r"C:\Windows\Fonts\calibrib.ttf" if bold else r"C:\Windows\Fonts\calibri.ttf",
        ]
        for candidate in candidates:
            try:
                return ImageFont.truetype(candidate, size)
            except OSError:
                continue
        return ImageFont.load_default()

    img = Image.new("RGB", (1600, 900), "white")
    draw = ImageDraw.Draw(img)
    title_font = get_font(30, True)
    subtitle_font = get_font(18)
    label_font = get_font(15)
    small_font = get_font(13)
    draw.text((55, 35), "JurisCom RegTech - AML/KYC Alert Analysis", fill="#111111", font=title_font)
    draw.text((55, 75), "Standard Chartered Bank (US vs Singapore) | 29 synthetic test transactions", fill="#555555", font=subtitle_font)
    draw.text((55, 135), "Alert Type Distribution by Jurisdiction", fill="#111111", font=subtitle_font)

    types = sorted(alert_counts.columns)
    max_count = max(1, int(alert_counts.max().max()))
    x0, y0, chart_h = 90, 610, 390
    group_w = 92
    draw.line([x0 - 20, y0, 760, y0], fill="#777777", width=2)
    draw.line([x0 - 20, y0, x0 - 20, y0 - chart_h - 20], fill="#777777", width=2)
    for i, alert_type in enumerate(types):
        us_count = int(alert_counts.loc["US_BSA_FinCEN"].get(alert_type, 0))
        sg_count = int(alert_counts.loc["SG_MAS_Notice626"].get(alert_type, 0))
        x = x0 + i * group_w
        for j, (count, color) in enumerate([(us_count, US_C), (sg_count, SG_C)]):
            h = int(chart_h * count / max_count)
            draw.rectangle([x + j * 30, y0 - h, x + 24 + j * 30, y0], fill=color)
            draw.text((x + j * 30 + 5, y0 - h - 22), str(count), fill="#111111", font=small_font)
        draw.text((x - 12, y0 + 14), alert_type.replace("_", "\n"), fill="#111111", font=small_font)
    draw.rectangle([90, 710, 116, 732], fill=US_C)
    draw.text((124, 710), "US BSA/FinCEN", fill="#111111", font=label_font)
    draw.rectangle([250, 710, 276, 732], fill=SG_C)
    draw.text((284, 710), "SG MAS Notice 626", fill="#111111", font=label_font)

    draw.text((890, 135), "Selected AML/KYC Thresholds (USD Equivalent)", fill="#111111", font=subtitle_font)
    tx0, ty0, th = 970, 610, 390
    max_threshold = 30000
    draw.line([900, ty0, 1470, ty0], fill="#777777", width=2)
    draw.line([900, ty0, 900, ty0 - th - 20], fill="#777777", width=2)
    for i, (label, value, color) in enumerate(zip(labels, thresholds, [US_C, SG_C])):
        h = int(th * value / max_threshold)
        x = tx0 + i * 250
        draw.rectangle([x, ty0 - h, x + 110, ty0], fill=color)
        draw.text((x + 10, ty0 - h - 28), f"${value:,.0f}", fill="#111111", font=label_font)
        draw.text((x - 35, ty0 + 16), label.replace("\n", " "), fill="#111111", font=small_font)
    sar_y = ty0 - int(th * US_CONFIG["str"]["threshold_usd"] / max_threshold)
    draw.line([920, sar_y, 1460, sar_y], fill="#f4a000", width=4)
    draw.text((925, sar_y - 28), "US SAR floor: $5,000 + suspicion", fill="#111111", font=label_font)
    draw.rounded_rectangle([955, 735, 1445, 805], radius=10, fill="#ffe5e5", outline="#d00000")
    draw.text((980, 757), "SG STR has no fixed monetary threshold", fill=SG_C, font=label_font)
    draw.text((980, 780), "The filing test is suspicion/risk-based.", fill="#333333", font=small_font)
    img.save(DATA_DIR / "threshold_comparison.png")
print(f"threshold_comparison.png written: {(DATA_DIR / 'threshold_comparison.png').exists()}")


def alert_types(engine: JurisdictionAlertEngine, txn_id: str) -> list[str]:
    txn = df[df["txn_id"] == txn_id].iloc[0].to_dict()
    return [a.alert_type for a in engine.evaluate(txn)]


def check_alert(label: str, txn_id: str, jurisdiction: str, alert_type: str, expected: bool) -> bool:
    engine = us_engine if jurisdiction == "US" else sg_engine
    types = alert_types(engine, txn_id)
    actual = alert_type in types
    passed = actual == expected
    status = "PASS" if passed else "FAIL"
    expectation = "has" if expected else "does not have"
    print(f"  {status}: {label} - {jurisdiction} {txn_id} {expectation} {alert_type}; actual={types or ['NONE']}")
    return passed


print("\n=== Jurisdiction-Differential Cases ===")
differential_cases = [
    ("TXN-SG-003", "A - US CTR vs SG one-off CDD threshold"),
    ("TXN-SG-007", "B - SG risk-based STR below US SAR floor"),
    ("TXN-SG-009", "C - Domestic PEP EDD gap"),
    ("TXN-US-011", "D - Beneficial ownership standard gap"),
]
all_pass = True
for txn_id, label in differential_cases:
    txn = df[df["txn_id"] == txn_id].iloc[0].to_dict()
    us_types = [a.alert_type for a in us_engine.evaluate(txn)] or ["NONE"]
    sg_types = [a.alert_type for a in sg_engine.evaluate(txn)] or ["NONE"]
    different = us_types != sg_types
    if not different:
        all_pass = False
    print(f"  Case {label}:")
    print(f"    US: {us_types}")
    print(f"    SG: {sg_types}")
    print(f"    Status: {'PASS' if different else 'SAME (check expected)'}")

print()
if all_pass:
    print("ALL 4 DIFFERENTIAL CASES VERIFIED - notebook logic is correct.")
else:
    print("WARNING: Some cases produced the same result in both jurisdictions.")


print("\n=== Trigger Coverage Checklist ===")
coverage_checks = [
    ("US CTR above threshold", "TXN-US-001", "US", "CTR", True),
    ("US CTR exact threshold", "TXN-US-013", "US", "CTR", True),
    ("US CTR same-day aggregation", "TXN-US-003", "US", "CTR", True),
    ("US CTR below threshold", "TXN-US-002", "US", "CTR", False),
    ("SG one-off CDD above local threshold", "TXN-SG-001", "SG", "CDD_ONE_OFF", True),
    ("SG one-off CDD exact local threshold", "TXN-SG-014", "SG", "CDD_ONE_OFF", True),
    ("SG one-off CDD USD branch", "TXN-SG-015", "SG", "CDD_ONE_OFF", True),
    ("SG one-off CDD below threshold", "TXN-SG-002", "SG", "CDD_ONE_OFF", False),
    ("US SAR exact floor plus suspicion", "TXN-US-014", "US", "SAR", True),
    ("US SAR above floor plus suspicion", "TXN-US-015", "US", "SAR", True),
    ("US SAR below floor despite suspicion", "TXN-US-004", "US", "SAR", False),
    ("SG STR structuring", "TXN-SG-004", "SG", "STR", True),
    ("SG STR high-risk country below US SAR floor", "TXN-SG-007", "SG", "STR", True),
    ("SG STR unusual pattern", "TXN-SG-008", "SG", "STR", True),
    ("SG STR partial sanctions review", "TXN-US-004", "SG", "STR", True),
    ("Full sanctions block", "TXN-US-005", "US", "SANCTIONS_BLOCK", True),
    ("US fuzzy sanctions block at 87%", "TXN-US-004", "US", "SANCTIONS_BLOCK", True),
    ("SG fuzzy sanctions block at 82%", "TXN-SG-016", "SG", "SANCTIONS_BLOCK", True),
    ("US fuzzy sanctions no-block at 82%", "TXN-SG-016", "US", "SANCTIONS_BLOCK", False),
    ("Fuzzy sanctions below both thresholds", "TXN-SG-017", "SG", "SANCTIONS_BLOCK", False),
    ("Foreign PEP EDD", "TXN-US-010", "US", "EDD_PEP", True),
    ("Domestic PEP gap under US config", "TXN-SG-009", "US", "EDD_PEP", False),
    ("Domestic PEP EDD under SG config", "TXN-SG-009", "SG", "EDD_PEP", True),
    ("US BO above threshold", "TXN-US-016", "US", "BO_FLAG", True),
    ("US BO exact threshold", "TXN-US-017", "US", "BO_FLAG", True),
    ("BO 24.9% gap under US config", "TXN-US-011", "US", "BO_FLAG", False),
    ("BO 24.9% reasonable-measures flag under SG config", "TXN-US-011", "SG", "BO_FLAG", True),
    ("Clean US baseline", "TXN-US-012", "US", "CTR", False),
    ("Clean SG baseline", "TXN-SG-013", "SG", "STR", False),
]
coverage_pass = True
for check in coverage_checks:
    coverage_pass = check_alert(*check) and coverage_pass

if coverage_pass:
    print("ALL TRIGGER COVERAGE CHECKS PASSED.")
else:
    raise AssertionError("At least one trigger coverage check failed.")

print("\n=== Structuring Detector Checks ===")
struct_checks = [
    ("US same-day structuring detected (TXN-US-003)", "TXN-US-003", "computed_structuring_us", True),
    ("US same-day structuring contrib (TXN-US-101)", "TXN-US-101", "computed_structuring_us", True),
    ("US same-day structuring contrib (TXN-US-102)", "TXN-US-102", "computed_structuring_us", True),
    ("US multi-day structuring detected (TXN-US-103)", "TXN-US-103", "computed_structuring_us", True),
    ("US legitimate small payroll NOT flagged (TXN-US-106)", "TXN-US-106", "computed_structuring_us", False),
    ("US clean baseline NOT flagged (TXN-US-012)", "TXN-US-012", "computed_structuring_us", False),
    ("SG same-day structuring detected (TXN-SG-004)", "TXN-SG-004", "computed_structuring_sg", True),
    ("SG multi-day structuring detected (TXN-SG-103)", "TXN-SG-103", "computed_structuring_sg", True),
    ("SG clean baseline NOT flagged (TXN-SG-013)", "TXN-SG-013", "computed_structuring_sg", False),
]
struct_pass = True
for label, txn_id, col, expected in struct_checks:
    actual = bool(df.loc[df["txn_id"] == txn_id, col].iloc[0])
    ok = actual == expected
    struct_pass = struct_pass and ok
    print(f"  {'PASS' if ok else 'FAIL'}: {label} (got {actual}, expected {expected})")
if not struct_pass:
    raise AssertionError("Structuring detector check failed.")
print("ALL STRUCTURING CHECKS PASSED.")


# === Section 9: ML Anomaly Detection + SHAP Explainability ===
import numpy as np

try:
    from sklearn.ensemble import IsolationForest
    SKLEARN_OK = True
except ModuleNotFoundError:
    SKLEARN_OK = False
    print("sklearn not installed; skipping ML/SHAP layer")

try:
    import shap
    SHAP_OK = True
except ModuleNotFoundError:
    SHAP_OK = False

ml_results = None
if SKLEARN_OK:
    feature_df = pd.DataFrame({
        "amount_usd": df["amount_usd"].astype(float),
        "same_day_cash_usd": df["same_day_cumulative_cash_usd"].astype(float),
        "sanctions_match_pct": df["sanctions_match_score_pct"].astype(float),
        "bo_pct": df["beneficial_owner_pct"].astype(float),
        "is_pep": df["is_pep"].astype(int),
        "is_sanctioned": df["is_sanctioned"].astype(int),
        "high_risk_country": df["high_risk_country"].astype(int),
        "structuring_us": df["computed_structuring_us"].astype(int),
        "structuring_sg": df["computed_structuring_sg"].astype(int),
        "txn_type_code": df["txn_type"].map({
            "cash_deposit": 1, "cash_withdrawal": 2, "cash_exchange": 3,
            "wire_transfer": 4, "trade_finance": 5,
        }).fillna(0).astype(int),
        "risk_rating_code": df["customer_risk_rating"].map({
            "low": 1, "medium": 2, "high": 3,
        }).fillna(0).astype(int),
    })
    X = feature_df.values
    iforest = IsolationForest(
        n_estimators=200, contamination=0.15, random_state=42, n_jobs=1
    )
    iforest.fit(X)
    df["iforest_score"] = iforest.decision_function(X)
    df["iforest_anomaly"] = (iforest.predict(X) == -1)
    df["iforest_rank"] = df["iforest_score"].rank(method="first", ascending=True).astype(int)

    flagged_by_rules = set(alerts_df["txn_id"]) if not alerts_df.empty else set()
    flagged_by_ml = set(df.loc[df["iforest_anomaly"], "txn_id"])
    only_rules = sorted(flagged_by_rules - flagged_by_ml)
    only_ml = sorted(flagged_by_ml - flagged_by_rules)
    both = sorted(flagged_by_rules & flagged_by_ml)
    n_anom = int(df["iforest_anomaly"].sum())
    print(f"\nIsolation Forest flagged {n_anom} of {len(df)} transactions as anomalous")
    print(f"  rules-only: {len(only_rules)}")
    print(f"  ML-only:    {len(only_ml)} -> {only_ml}")
    print(f"  both:       {len(both)}")
    ml_results = {
        "only_rules": only_rules, "only_ml": only_ml, "both": both,
        "iforest": iforest, "feature_df": feature_df,
    }
    coverage_summary = pd.DataFrame([
        {"coverage_bucket": "rules_only", "transaction_count": len(only_rules), "txn_ids": ";".join(only_rules)},
        {"coverage_bucket": "ml_only", "transaction_count": len(only_ml), "txn_ids": ";".join(only_ml)},
        {"coverage_bucket": "both_rules_and_ml", "transaction_count": len(both), "txn_ids": ";".join(both)},
    ])
    coverage_summary.to_csv(DATA_DIR / "rules_ml_coverage.csv", index=False)
    print(f"rules_ml_coverage.csv written: {(DATA_DIR / 'rules_ml_coverage.csv').exists()}")

    ml_export = pd.concat(
        [
            df[[
                "txn_id",
                "customer_id",
                "txn_type",
                "amount_usd",
                "same_day_cumulative_cash_usd",
                "computed_structuring_us",
                "computed_structuring_sg",
                "iforest_score",
                "iforest_rank",
                "iforest_anomaly",
            ]],
            feature_df.add_prefix("feature_"),
        ],
        axis=1,
    )
    ml_export["rules_triggered"] = ml_export["txn_id"].map(
        lambda tid: ";".join(alerts_df.loc[alerts_df["txn_id"] == tid, "alert_type"].unique())
    )
    ml_export.to_csv(DATA_DIR / "isolation_forest_results.csv", index=False)
    print(f"isolation_forest_results.csv written: {(DATA_DIR / 'isolation_forest_results.csv').exists()}")

    sensitivity_rows = []
    for contamination in [0.05, 0.10, 0.15, 0.20]:
        model = IsolationForest(
            n_estimators=200,
            contamination=contamination,
            random_state=42,
            n_jobs=1,
        )
        model.fit(X)
        flagged_by_ml_param = set(df.loc[model.predict(X) == -1, "txn_id"])
        sensitivity_rows.append({
            "parameter_type": "iforest_contamination",
            "parameter_value": contamination,
            "total_rule_alerts": len(alerts_df),
            "us_structuring_flags": int(df["computed_structuring_us"].sum()),
            "sg_structuring_flags": int(df["computed_structuring_sg"].sum()),
            "iforest_anomalies": len(flagged_by_ml_param),
            "rules_only": len(flagged_by_rules - flagged_by_ml_param),
            "ml_only": len(flagged_by_ml_param - flagged_by_rules),
            "both_rules_and_ml": len(flagged_by_rules & flagged_by_ml_param),
            "interpretation": "Higher contamination forces more transactions into anomaly review.",
        })

    for lookback in [3, 5, 7, 14]:
        candidate_df = df.copy()
        candidate_df["computed_structuring_us"] = StructuringDetector(US_CONFIG, lookback_days=lookback).detect(candidate_df)
        candidate_df["computed_structuring_sg"] = StructuringDetector(SG_CONFIG, lookback_days=lookback).detect(candidate_df)
        candidate_alerts = pd.DataFrame(collect_alert_rows(candidate_df))
        sensitivity_rows.append({
            "parameter_type": "structuring_lookback_days",
            "parameter_value": lookback,
            "total_rule_alerts": len(candidate_alerts),
            "us_structuring_flags": int(candidate_df["computed_structuring_us"].sum()),
            "sg_structuring_flags": int(candidate_df["computed_structuring_sg"].sum()),
            "iforest_anomalies": "",
            "rules_only": "",
            "ml_only": "",
            "both_rules_and_ml": "",
            "interpretation": "Longer lookbacks catch more multi-day smurfing but increase review workload.",
        })

    sensitivity_df = pd.DataFrame(sensitivity_rows)
    sensitivity_df.to_csv(DATA_DIR / "sensitivity_analysis.csv", index=False)
    print(f"sensitivity_analysis.csv written: {(DATA_DIR / 'sensitivity_analysis.csv').exists()}")

    # SHAP visualisations (best-effort; degrade gracefully)
    if SHAP_OK and plt is not None:
        shap_values = None
        expected_value = None
        try:
            tree_explainer = shap.TreeExplainer(iforest)
            shap_values = tree_explainer.shap_values(X)
            expected_value = tree_explainer.expected_value
            if isinstance(expected_value, (list, np.ndarray)) and not np.isscalar(expected_value):
                expected_value = float(np.asarray(expected_value).flatten()[0])
        except Exception as exc:
            print(f"  TreeExplainer failed ({exc}); falling back")
            try:
                background = X[: min(20, len(X))]
                ke = shap.KernelExplainer(iforest.decision_function, background)
                shap_values = ke.shap_values(X, nsamples=100, silent=True)
                expected_value = float(ke.expected_value)
            except Exception as exc2:
                print(f"  KernelExplainer also failed ({exc2}); skipping SHAP")

        if shap_values is not None:
            mean_abs = np.abs(shap_values).mean(axis=0)
            shap_feature_importance = pd.DataFrame({
                "feature": feature_df.columns,
                "mean_abs_shap": mean_abs,
            }).sort_values("mean_abs_shap", ascending=False)
            shap_feature_importance.to_csv(DATA_DIR / "shap_feature_importance.csv", index=False)

            try:
                shap.summary_plot(shap_values, feature_df, show=False, plot_size=(10, 6))
                plt.title("SHAP Feature Importance - Isolation Forest Anomaly Drivers")
                plt.tight_layout()
                plt.savefig(DATA_DIR / "shap_summary.png", dpi=150, bbox_inches="tight")
                plt.close()
                print(f"shap_summary.png written: {(DATA_DIR / 'shap_summary.png').exists()}")
            except Exception as exc:
                print(f"  summary_plot failed ({exc}); writing manual bar chart")
                mean_abs = np.abs(shap_values).mean(axis=0)
                order = np.argsort(mean_abs)[::-1]
                fig, ax = plt.subplots(figsize=(9, 5))
                ax.barh(
                    [feature_df.columns[i] for i in order][::-1],
                    mean_abs[order][::-1],
                    color="#1f4e79",
                )
                ax.set_xlabel("Mean |SHAP value|")
                ax.set_title("SHAP Feature Importance (manual fallback)")
                plt.tight_layout()
                plt.savefig(DATA_DIR / "shap_summary.png", dpi=150, bbox_inches="tight")
                plt.close()

            anomalous_idx = df["iforest_score"].idxmin()
            anom_txn_id = df.loc[anomalous_idx, "txn_id"]
            print(f"Most-anomalous transaction (lowest iforest_score): {anom_txn_id}")
            shap_waterfall_values = pd.DataFrame({
                "txn_id": anom_txn_id,
                "feature": feature_df.columns,
                "feature_value": feature_df.loc[anomalous_idx].values,
                "shap_contribution": shap_values[anomalous_idx],
            }).assign(abs_contribution=lambda x: x["shap_contribution"].abs()).sort_values("abs_contribution", ascending=False)
            shap_waterfall_values.to_csv(DATA_DIR / "shap_waterfall_values.csv", index=False)
            try:
                shap.plots._waterfall.waterfall_legacy(
                    expected_value if expected_value is not None else 0.0,
                    shap_values[anomalous_idx],
                    feature_names=feature_df.columns.tolist(),
                    show=False,
                )
                plt.title(f"SHAP Waterfall - {anom_txn_id}")
                plt.tight_layout()
                plt.savefig(DATA_DIR / "shap_waterfall_anomaly.png", dpi=150, bbox_inches="tight")
                plt.close()
                print(f"shap_waterfall_anomaly.png written: {(DATA_DIR / 'shap_waterfall_anomaly.png').exists()}")
            except Exception as exc:
                print(f"  waterfall failed ({exc}); writing manual contribution bar")
                contrib = shap_values[anomalous_idx]
                order = np.argsort(np.abs(contrib))[::-1]
                fig, ax = plt.subplots(figsize=(9, 5))
                colors = ["#c00000" if c < 0 else "#1f4e79" for c in contrib[order][::-1]]
                ax.barh(
                    [feature_df.columns[i] for i in order][::-1],
                    contrib[order][::-1],
                    color=colors,
                )
                ax.axvline(0, color="black", lw=0.7)
                ax.set_xlabel("SHAP contribution to anomaly score (negative = more anomalous)")
                ax.set_title(f"SHAP contributions for {anom_txn_id}")
                plt.tight_layout()
                plt.savefig(DATA_DIR / "shap_waterfall_anomaly.png", dpi=150, bbox_inches="tight")
                plt.close()
    elif not SHAP_OK:
        print("shap not installed; skipping SHAP plots (pip install shap to enable)")


