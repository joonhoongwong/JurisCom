# Task 3 - Jurisdiction-Aware AML/KYC Prototype

This folder contains the Task 3 submission package for the RegTech AML/KYC prototype. It compares US BSA/FinCEN and Singapore MAS Notice 626 rule outcomes, adds an Isolation Forest review-prioritisation layer, and records data-source freshness for FX and sanctions inputs.

## Quick Start

Requirements: **Python 3.10 or newer** (built and validated on Python 3.14). Internet access is used to refresh the FX rate (Frankfurter public API) and OFAC/UN sanctions XML; if offline, the verifier falls back to the cached files in `Task3_data/` and prints a warning.

1. Install dependencies:

```powershell
python -m pip install -r Task3_requirements.txt
```

2. Run the verification and rebuild script:

```powershell
python run_all.py
```

Expected result: the script refreshes sanctions-source status, runs all checklist tests, rebuilds `Task3_notebook.ipynb`, and writes `Task3_submission.zip`.

3. Open the reviewer GUI:

```powershell
.\Open_Task3_GUI.bat
```

On macOS/Linux (or if the .bat is inconvenient), run Streamlit directly:

```bash
python -m streamlit run Task3_streamlit_app.py
```

Expected result: Streamlit starts at `http://localhost:8501` and opens the AML/KYC reviewer cockpit in your default browser.

## Main Files

- `Task3_verify_notebook.py` - source-of-truth verifier, rules engine, ML layer, SHAP outputs, and evidence artifact generator.
- `Task3_notebook.ipynb` - notebook wrapper generated from the verifier output.
- `Task3_streamlit_app.py` - reviewer-facing Streamlit GUI.
- `Open_Task3_GUI.bat` - the single launcher retained for the GUI.
- `run_all.py` - Task 3-only rebuild and zip script.
- `Task3_config/` - US, Singapore, FX, and sanctions source configuration.
- `Task3_data/` - synthetic transactions, generated alert outputs, ML outputs, charts, and sanctions cache.
- `Task3_model_card.md`, `Task3_summary.md`, `Task3_Flow_and_Logic.md` - written explanation, model card, and trigger logic guide.

## Verification Checklist

Running `python Task3_verify_notebook.py` should report:

- `ALL 4 DIFFERENTIAL CASES VERIFIED`
- `ALL TRIGGER COVERAGE CHECKS PASSED`
- `ALL STRUCTURING CHECKS PASSED`
- regenerated CSV/PNG evidence files in `Task3_data/`

## Sanctions Cache Note

The `Task3_data/sanctions_cache/` folder is intentionally retained for offline reproducibility. It contains cached public OFAC, UN, and MAS source artifacts used by the freshness-control demonstration. The MAS TFS scraper is explicitly documented as best-effort and still requiring manual/legal review or a licensed production feed.
