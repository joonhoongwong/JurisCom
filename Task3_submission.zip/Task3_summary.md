# Task 3: One-Page Design Summary
**JurisCom RegTech — Jurisdiction-Aware AML/KYC Compliance Tool**  
**Wong Joon Hoong | G2505242K | joonhoongwong@yahoo.com**

---

## The Problem in One Sentence

Standard Chartered Bank books transactions in 59+ markets. A single AML/KYC rule engine calibrated to one jurisdiction will produce systematic compliance errors in every other jurisdiction — either over-reporting (wasting compliance resources and harming customers) or under-reporting (creating regulatory and criminal liability).

## What the Tool Does

The tool applies jurisdiction-specific AML/KYC rules to individual transactions and customer records, producing structured compliance alerts (CTR, CDD_ONE_OFF, SAR/STR, sanctions block, PEP enhanced due diligence, beneficial ownership flag). The same alert engine evaluates every transaction under both US (BSA/FinCEN) and Singapore (MAS Notice 626) configs, making the jurisdictional gap visible and auditable. It also computes 7-day rolling structuring patterns and demonstrates an optional Isolation Forest + SHAP anomaly explanation layer.

## The Core Design Choice: Config Over Code

All jurisdiction-specific logic lives in JSON configuration files, not in application code. Adding a new jurisdiction, or updating a threshold when a regulation changes, requires only a JSON file update — not a software release. This means:

- **Regulatory changes are cheap to implement** — a compliance lawyer can review the JSON diff without reading Python
- **Version history is meaningful** — git history of a JSON file is a complete audit trail of what rule was applied when
- **The engine is jurisdiction-agnostic** — it knows how to evaluate sanctions, US CTR thresholds, Singapore one-off CDD thresholds, PEP rules, and beneficial ownership; it does not know which jurisdiction it is in until it loads a config

## Four Cases That Show Why This Matters

The prototype demonstrates four transactions that produce opposite compliance outcomes depending on which jurisdiction's rules are active:

| Case | Transaction | US Result | SG Result |
|---|---|---|---|
| A | SGD 18,000 one-off cash exchange by non-account holder | **CTR filed** if booked in the US (USD-equivalent at current FX exceeds the $10k threshold; see `Task3_data/fx_rate_status.csv`) | No one-off CDD threshold trigger (SGD 18k < SGD 20k) |
| B | SGD 3,000 trade finance to Myanmar | No SAR (below $5k SAR floor, even if risk is visible) | **STR filed** (risk-based: high-risk country counterparty) |
| C | SGD 8,000 withdrawal by domestic PEP | No action (US has no domestic PEP EDD) | **EDD triggered** (MAS requires EDD + SM approval for domestic PEPs) |
| D | USD 120,000 corporate trade finance; UBO 24.9%, undisclosed | No BO flag (24.9% < 25% bright-line and no separate US SAR suspicion flag) | **STR + BO_FLAG** (SG reasonable measures: any undisclosed corporate flagged) |

Without jurisdiction-aware tooling, SCB's compliance team would either apply US rules to Singapore-booked transactions (missing Cases B, C and D) or apply Singapore rules to US-booked transactions (generating unnecessary CDD/EDD actions in the wrong booking context).

## Evidence Layer Added

To make the prototype more defensible, the verifier now exports a public-record enforcement scenario back-test, sanctions source-freshness status, sensitivity analysis, and rules-vs-ML coverage table.

| Evidence artifact | Result | Why it matters |
|---|---|---|
| `public_enforcement_backtest.csv` | Iran, Myanmar/Burma, Syria, Sudan, and Zimbabwe scenarios all surface under at least one alert path | Demonstrates how the engine behaves against public SCB enforcement themes without claiming access to real bank data |
| `sanctions_refresh_status.csv` | OFAC SDN XML + UN Consolidated XML refresh into local cache; MAS TFS landing page is now scraped weekly with maintenance-page and JS-render detection (status example: `MAINTENANCE_PAGE_DETECTED` when MAS is in a maintenance window) | Converts "static sanctions data" into a monitored source-freshness control across three jurisdictions; MAS PDF body parsing remains an explicit boundary requiring legal review or a licensed vendor feed |
| `rules_ml_coverage.csv` | 29 rules-only, 0 ML-only, 7 both rules and ML | Shows the ML layer confirms high-risk rule alerts in this small synthetic set rather than making unsupported novel-typology claims |
| `sensitivity_analysis.csv` | Contamination 0.05->0.20 changes anomalies 3->9; structuring lookback 3->7 days changes rule alerts 58->63 | Shows the review-volume tradeoff a bank model-risk team would need to approve |

## What the Tool Deliberately Does Not Do

- **No production ML filing decision.** The prototype includes a small Isolation Forest + SHAP explainability demo to answer the assignment's XAI prompt, but the actual SAR/STR decision remains rules-based and subject to human review because we do not have labelled historical outcomes.
- **No real-time payment blocking.** All alerts are subject to mandatory human review before customer-facing action. The tool produces a structured alert with a reason and rule reference; a compliance analyst makes the decision.
- **Partial live data feeds only.** FX refreshes from a public online API into `fx_rates.json`; OFAC SDN + UN Consolidated XML refresh into local cache with staleness checks; the MAS TFS landing page is scraped weekly with maintenance-page and JS-render detection (the scraper correctly surfaced a MAS maintenance window during build, which is the exact freshness signal the control exists for). PDF body parsing of MAS designations remains a manual legal step, and production still needs licensed data, vendor-grade name screening, and either a headless-browser pipeline or an authorised MAS feed.
- **Multi-jurisdiction conflict is documented, not auto-resolved.** When a transaction touches both jurisdictions, the tool runs both configs and produces two parallel alert sets. Slide 11 documents three policy options the bank can adopt (booking-entity-wins, most-restrictive-rule, counterparty-touches); the tool deliberately does not hard-code one because precedence is a bank-policy decision and a vendor-imposed default could be read as the bank ceding judgement to a vendor.
- **No SWIFT message-integrity control.** The tool does not ingest MT103/MT202 messages or detect field stripping; this is a separate payment-integrity product boundary.
- **No full case-management workflow.** The prototype writes alert evidence but does not assign analysts, record dispositions, manage filing approval, or submit SAR/STR filings.
- **No graph/network typology model.** It does not resolve complex ownership chains, TBML networks, crypto flows, or cross-entity smurfing beyond the available transaction feed.

## The Design Choice That Reflects Genuine Risk vs Documentation

We included the SG risk-based STR logic in the prototype even though US rules do not require it for US-booked transactions. This surfaces cases where Singapore rules would catch genuine risk that US threshold-based rules miss entirely — not because it improves documentation, but because it helps a compliance analyst see the full regulatory picture across both booking locations. The tradeoff is higher alert volume and more false positives from high-risk country flagging; we acknowledge this honestly in the model card.

## What We Would Add With More Time

1. **Production FX source integration** (replace the public prototype API with MAS or a licensed market-data feed, using the existing `fx_rates.json` freshness pattern)
2. **Production sanctions screening integration** (use the new OFAC/UN refresh status as the control pattern, then add MAS-specific TFS ingestion, alias/transliteration logic, delta approval, and false-positive workflow)
3. **Multi-jurisdiction conflict resolution policy** (most-restrictive-rule default)
4. **Cross-entity structuring detection** (the prototype now handles 7-day rolling windows within the available transaction feed; production should aggregate across related customers, branches, and entities)
5. **Production-calibrated risk scoring model** (0-100 composite score incorporating transaction type, counterparty risk, customer risk rating, and jurisdictional factors)
6. **Case management workflow** allowing analysts to record dispositions, evidence, and filing outcomes

The core architecture is sound. The gaps are integration and feature completeness, not design flaws.
