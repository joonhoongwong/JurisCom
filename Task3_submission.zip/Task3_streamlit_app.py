"""Streamlit demo UI for the Task 3 jurisdiction-aware AML/KYC prototype.

Run:
    streamlit run Task3_streamlit_app.py

The app is intentionally a reviewer cockpit: it lets a non-technical evaluator
inspect transactions, compare US vs Singapore alerts, triage generated alerts,
and see source-data freshness for FX/sanctions. It reuses generated artifacts
from the verifier instead of maintaining a second rules engine.
"""
from __future__ import annotations

import json
import subprocess
import sys
from io import StringIO
from pathlib import Path

import pandas as pd
import streamlit as st


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "Task3_data"
CONFIG_DIR = BASE_DIR / "Task3_config"


st.set_page_config(
    page_title="JurisCom AML/KYC Demo",
    layout="wide",
)


@st.cache_data(show_spinner=False)
def read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path)


@st.cache_data(show_spinner=False)
def read_json(path: Path) -> dict:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def format_alerts(alerts: pd.DataFrame) -> str:
    if alerts.empty:
        return "No alert"
    return ", ".join(alerts["alert_type"].astype(str).tolist())


ALERT_COLUMNS = [
    "txn_id",
    "jurisdiction",
    "config_applied",
    "alert_type",
    "reason",
    "rule_ref",
    "action_required",
    "filing_deadline",
]

NUMERIC_COLUMNS = [
    "amount_local",
    "amount_usd",
    "same_day_cumulative_cash_usd",
    "beneficial_owner_pct",
    "sanctions_match_score_pct",
]

BOOL_COLUMNS = [
    "is_pep",
    "is_sanctioned",
    "high_risk_country",
    "beneficial_owner_disclosed",
    "structuring_flag",
    "has_business_relationship",
    "suspicious_activity_flag",
]

DEFAULT_TRANSACTION = {
    "txn_id": "ADHOC-001",
    "booking_entity": "SCB_SG",
    "txn_date": "2024-11-30",
    "txn_type": "wire_transfer",
    "amount_local": 25000,
    "currency": "SGD",
    "amount_usd": 18575,
    "customer_id": "ADHOC-CUST",
    "customer_name": "Ad Hoc Customer",
    "customer_type": "individual",
    "customer_risk_rating": "medium",
    "is_pep": False,
    "pep_type": "none",
    "is_sanctioned": False,
    "sanctions_list_hit": "none",
    "sanctions_match_score_pct": 0,
    "beneficial_owner_pct": 0,
    "beneficial_owner_disclosed": True,
    "country_of_origin": "SG",
    "high_risk_country": False,
    "counterparty_name": "External Counterparty",
    "counterparty_country": "SG",
    "same_day_cumulative_cash_usd": 18575,
    "structuring_flag": False,
    "unusual_pattern_notes": "none",
    "purpose_of_txn": "business_payment",
    "has_business_relationship": True,
    "suspicious_activity_flag": False,
}


def status_badge(value: str) -> str:
    value = str(value)
    if value == "OK":
        return "OK"
    if value in {"MANUAL_LIMITATION", "STALE"}:
        return "Needs review"
    return "Problem"


COUNTRY_ALIASES = {
    "AF": "Afghanistan",
    "AE": "United Arab Emirates UAE",
    "CN": "China",
    "IR": "Iran",
    "IQ": "Iraq",
    "JP": "Japan",
    "KP": "North Korea DPRK",
    "LY": "Libya",
    "MM": "Myanmar Burma",
    "MX": "Mexico",
    "RU": "Russia",
    "SD": "Sudan",
    "SG": "Singapore",
    "SO": "Somalia",
    "SY": "Syria",
    "US": "United States America USA",
    "VG": "British Virgin Islands BVI",
    "YE": "Yemen",
}

SEARCH_COLUMNS = [
    "txn_id",
    "booking_entity",
    "txn_type",
    "currency",
    "customer_id",
    "customer_name",
    "customer_type",
    "customer_risk_rating",
    "pep_type",
    "sanctions_list_hit",
    "country_of_origin",
    "counterparty_name",
    "counterparty_country",
    "unusual_pattern_notes",
    "purpose_of_txn",
]


def clean_value(value: object) -> str:
    if pd.isna(value):
        return ""
    return str(value)


def bool_value(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if pd.isna(value):
        return False
    return str(value).strip().lower() in {"true", "1", "yes", "y"}


def command_output_tail(text: str, limit: int = 14000) -> str:
    text = text or ""
    return text if len(text) <= limit else text[-limit:]


def run_project_command(script_name: str, label: str, timeout_seconds: int = 240) -> None:
    script_path = BASE_DIR / script_name
    if not script_path.exists():
        st.error(f"{script_name} was not found in this folder.")
        return
    try:
        result = subprocess.run(
            [sys.executable, str(script_path)],
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
        )
        output = "\n".join(part for part in [result.stdout, result.stderr] if part)
        st.session_state["last_command"] = {
            "label": label,
            "returncode": result.returncode,
            "output": command_output_tail(output),
        }
    except subprocess.TimeoutExpired as exc:
        output = "\n".join(part for part in [exc.stdout or "", exc.stderr or ""] if part)
        st.session_state["last_command"] = {
            "label": label,
            "returncode": -1,
            "output": command_output_tail(output + "\nCommand timed out."),
        }
    st.cache_data.clear()
    st.rerun()


def render_command_center() -> None:
    with st.expander("Regenerate artifacts and refresh sources from the GUI", expanded=False):
        st.caption(
            "These buttons call the same Task 3 scripts listed in the README. They update files in this folder, "
            "then reload the Streamlit cache."
        )
        c1, c2, c3 = st.columns(3)
        if c1.button("Run full rebuild", use_container_width=True):
            run_project_command("run_all.py", "python run_all.py", timeout_seconds=360)
        if c2.button("Run verifier/checklist", use_container_width=True):
            run_project_command("Task3_verify_notebook.py", "python Task3_verify_notebook.py")
        if c3.button("Refresh sanctions lists", use_container_width=True):
            run_project_command("Task3_sanctions_refresh.py", "python Task3_sanctions_refresh.py")

        guide_cols = st.columns(2)
        guide_path = BASE_DIR / "Task3_Flow_and_Logic.md"
        model_card_path = BASE_DIR / "Task3_model_card.md"
        if guide_path.exists():
            guide_cols[0].download_button(
                "Download flow and trigger guide",
                guide_path.read_bytes(),
                file_name=guide_path.name,
                mime="text/markdown",
                use_container_width=True,
            )
        if model_card_path.exists():
            guide_cols[1].download_button(
                "Download model card",
                model_card_path.read_bytes(),
                file_name=model_card_path.name,
                mime="text/markdown",
                use_container_width=True,
            )

    last_command = st.session_state.get("last_command")
    if last_command:
        ok = last_command.get("returncode") == 0
        message = f"Last command: {last_command.get('label')}"
        (st.success if ok else st.error)(message)
        with st.expander("Show command output", expanded=not ok):
            st.code(last_command.get("output", ""), language="text")


def transaction_search_text(row: pd.Series) -> str:
    parts = [clean_value(row.get(col, "")) for col in SEARCH_COLUMNS]
    for col in ["country_of_origin", "counterparty_country"]:
        code = clean_value(row.get(col, "")).upper()
        if code in COUNTRY_ALIASES:
            parts.append(COUNTRY_ALIASES[code])
    return " ".join(parts).lower()


def filter_transactions(df: pd.DataFrame, query: str) -> pd.DataFrame:
    query = query.strip().lower()
    if not query:
        return df
    tokens = query.split()
    search_text = df.apply(transaction_search_text, axis=1)
    mask = search_text.map(lambda text: all(token in text for token in tokens))
    return df.loc[mask].copy()


def transaction_label(row: pd.Series) -> str:
    amount = f"{clean_value(row.get('amount_local'))} {clean_value(row.get('currency'))}".strip()
    counterparty = clean_value(row.get("counterparty_name")) or "N/A"
    return f"{row['txn_id']} | {row['customer_name']} -> {counterparty} | {amount}"


def prepare_transactions_for_eval(input_df: pd.DataFrame, us_config: dict, sg_config: dict) -> pd.DataFrame:
    df = input_df.copy()
    for column, default in DEFAULT_TRANSACTION.items():
        if column not in df.columns:
            df[column] = default
    for col in NUMERIC_COLUMNS:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    for col in BOOL_COLUMNS:
        df[col] = df[col].map(bool_value)
    df["computed_structuring_us"] = detect_structuring(df, us_config)
    df["computed_structuring_sg"] = detect_structuring(df, sg_config)
    return df


def detect_structuring(df: pd.DataFrame, config: dict) -> pd.Series:
    flags = pd.Series(False, index=df.index)
    ctr = config.get("ctr", {}) or {}
    cdd = config.get("non_account_cdd", {}) or {}
    if ctr.get("enabled", True) and ctr.get("threshold_local"):
        source = ctr
    elif cdd.get("enabled") and cdd.get("threshold_local"):
        source = cdd
    else:
        return flags
    threshold_local = float(source.get("threshold_local") or 0)
    applies_to = set(source.get("applies_to") or [])
    min_txns = int(source.get("structuring_min_txns_in_window") or 3)
    lookback_days = int(source.get("structuring_lookback_days") or 7)
    if threshold_local <= 0 or not applies_to:
        return flags
    working = df.copy()
    working["_date"] = pd.to_datetime(working["txn_date"], errors="coerce")
    mask = (
        working["txn_type"].isin(applies_to)
        & (working["currency"].astype(str).str.upper() == str(config.get("currency", "")).upper())
        & (working["amount_local"].astype(float) < threshold_local)
        & working["_date"].notna()
    )
    cash = working.loc[mask].copy()
    for _, group in cash.groupby("customer_id"):
        group = group.sort_values("_date")
        for _, row in group.iterrows():
            window_start = row["_date"] - pd.Timedelta(days=lookback_days - 1)
            in_window = group[(group["_date"] >= window_start) & (group["_date"] <= row["_date"])]
            if len(in_window) >= min_txns and in_window["amount_local"].astype(float).sum() >= threshold_local:
                flags.loc[in_window.index] = True
    return flags


def make_alert(txn: dict, config: dict, config_applied: str, alert_type: str, reason: str, rule_ref: str, action: str, deadline: str = "") -> dict:
    return {
        "txn_id": txn["txn_id"],
        "jurisdiction": config["jurisdiction"],
        "config_applied": config_applied,
        "alert_type": alert_type,
        "reason": reason,
        "rule_ref": rule_ref,
        "action_required": action,
        "filing_deadline": deadline,
    }


def evaluate_transaction(txn: dict, config: dict, config_applied: str) -> list[dict]:
    alerts_out: list[dict] = []
    hit = str(txn.get("sanctions_list_hit", "none")).strip().lower()
    score = float(txn.get("sanctions_match_score_pct", 0) or 0)
    sanctions = config.get("sanctions", {})
    sanctions_threshold = float(sanctions.get("match_threshold_pct", 100))
    exact_hit = bool_value(txn.get("is_sanctioned")) or hit in {"sdn", "mas_tfs", "un_tfs", "ofac_sdn", "un_designated"}
    fuzzy_hit = score >= sanctions_threshold
    if exact_hit or fuzzy_hit:
        reasons = []
        if exact_hit:
            reasons.append(f"list hit: {hit}")
        if score:
            reasons.append(f"match score {score:,.0f}% >= threshold {sanctions_threshold:,.0f}%")
        alerts_out.append(make_alert(
            txn,
            config,
            config_applied,
            "SANCTIONS_BLOCK",
            "; ".join(reasons),
            f"{config['regulation']} sanctions program",
            "BLOCK + file STR/SAR; escalate",
        ))

    ctr = config.get("ctr", {})
    if ctr.get("enabled", True) and ctr.get("threshold_usd") is not None and txn["txn_type"] in ctr.get("applies_to", []):
        cumulative_usd = float(txn.get("same_day_cumulative_cash_usd", 0) or 0)
        if cumulative_usd >= float(ctr["threshold_usd"]):
            alerts_out.append(make_alert(
                txn,
                config,
                config_applied,
                ctr["abbreviation"],
                f"USD {cumulative_usd:,.0f} >= threshold {ctr['threshold_usd']:,}",
                f"{config['regulation']} - {ctr['form']}",
                f"File {ctr['abbreviation']} within {ctr['filing_deadline_days']} days",
                f"{ctr['filing_deadline_days']} calendar days",
            ))

    cdd = config.get("non_account_cdd", {})
    if cdd.get("enabled") and not bool_value(txn.get("has_business_relationship", True)) and txn["txn_type"] in cdd.get("applies_to", []):
        if str(txn["currency"]).upper() == str(config["currency"]).upper():
            value = float(txn.get("amount_local", 0) or 0)
            threshold = float(cdd["threshold_local"])
            label = f"{config['currency']} {value:,.0f} >= threshold {threshold:,.0f}"
        else:
            value = float(txn.get("amount_usd", 0) or 0)
            threshold = float(cdd["threshold_usd"])
            label = f"USD {value:,.0f} >= threshold {threshold:,.0f}"
        if value >= threshold:
            alerts_out.append(make_alert(
                txn,
                config,
                config_applied,
                cdd["abbreviation"],
                label,
                cdd["rule_ref"],
                "Perform and document CDD for non-account-holder transaction",
            ))

    str_cfg = config.get("str", {})
    structuring_col = f"computed_structuring_{config['jurisdiction'].lower()}"
    structuring = bool_value(txn.get(structuring_col, txn.get("structuring_flag", False)))
    high_risk = bool_value(txn.get("high_risk_country", False))
    unusual = str(txn.get("unusual_pattern_notes", "")).strip().lower()
    unusual = "" if unusual == "none" else unusual
    partial_sanctions_match = hit not in {"", "none"} or score > 0
    if not bool_value(txn.get("is_sanctioned", False)):
        if str_cfg.get("no_fixed_threshold"):
            reasons = []
            if structuring:
                reasons.append("structuring pattern")
            if high_risk:
                reasons.append(f"high-risk country ({txn.get('counterparty_country', '')})")
            if partial_sanctions_match:
                reasons.append("sanctions partial/fuzzy match")
            if unusual:
                reasons.append(unusual)
            if reasons:
                alerts_out.append(make_alert(
                    txn,
                    config,
                    config_applied,
                    "STR",
                    f"Risk-based STR: {'; '.join(reasons)}",
                    f"{config['regulation']} - STR ({str_cfg['regulator']})",
                    "File STR with STRO as soon as practicable; no tipping off",
                ))
        else:
            threshold = float(str_cfg.get("threshold_usd") or 0)
            sar_amount = max(float(txn.get("amount_usd", 0) or 0), float(txn.get("same_day_cumulative_cash_usd", 0) or 0))
            reasons = []
            if structuring:
                reasons.append("structuring pattern")
            if partial_sanctions_match:
                reasons.append("sanctions partial/fuzzy match")
            if bool_value(txn.get("suspicious_activity_flag", False)):
                reasons.append(unusual or "reason to suspect")
            if sar_amount >= threshold and reasons:
                alerts_out.append(make_alert(
                    txn,
                    config,
                    config_applied,
                    "SAR",
                    f"USD {sar_amount:,.0f} >= SAR floor {threshold:,.0f}; " + "; ".join(reasons),
                    f"{config['regulation']} - SAR ({str_cfg['rule_ref']})",
                    f"File SAR with FinCEN within {str_cfg['filing_deadline_days']} days",
                    f"{str_cfg['filing_deadline_days']} calendar days",
                ))

    pep = config.get("pep", {})
    pep_type = str(txn.get("pep_type", "none")).strip().lower()
    if pep_type != "none":
        domestic = pep_type == "domestic"
        if (domestic and pep.get("domestic_pep_enhanced_dd")) or ((not domestic) and pep.get("foreign_pep_enhanced_dd")):
            extras = []
            if pep.get("senior_management_approval_required"):
                extras.append("SM approval required")
            if pep.get("source_of_wealth_required"):
                extras.append("source of wealth required")
            alerts_out.append(make_alert(
                txn,
                config,
                config_applied,
                "EDD_PEP",
                f"{pep_type.upper()} PEP - EDD required" + (("; " + "; ".join(extras)) if extras else ""),
                config["regulation"],
                "Initiate EDD; collect source of wealth",
            ))

    if txn.get("customer_type") == "corporate":
        bo = config.get("beneficial_ownership", {})
        disclosed = bool_value(txn.get("beneficial_owner_disclosed", False))
        pct = float(txn.get("beneficial_owner_pct", 0) or 0)
        threshold = float(bo.get("threshold_pct", 25))
        if not disclosed and pct >= threshold:
            alerts_out.append(make_alert(
                txn,
                config,
                config_applied,
                "BO_FLAG",
                f"UBO {pct}% >= {threshold}% threshold; not disclosed",
                bo["rule_ref"],
                "Collect BO certification before further activity",
            ))
        elif not disclosed and bo.get("standard") != "bright_line":
            reason = "No UBO information on file; reasonable-measures inquiry required" if pct == 0 else (
                f"Partial UBO ({pct}%) below {threshold}% threshold and undisclosed; reasonable-measures inquiry required"
            )
            action = "Escalate to MLRO; document inquiry; consider relationship suspension if UBO unidentifiable" if pct == 0 else (
                "Document reasonable measures taken; record residual unknown ownership"
            )
            alerts_out.append(make_alert(txn, config, config_applied, "BO_FLAG", reason, bo["rule_ref"], action))
    return alerts_out


def evaluate_dataframe(input_df: pd.DataFrame, us_config: dict, sg_config: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    prepared = prepare_transactions_for_eval(input_df, us_config, sg_config)
    rows = []
    for _, row in prepared.iterrows():
        txn = row.to_dict()
        rows.extend(evaluate_transaction(txn, us_config, "US_BSA_FinCEN"))
        rows.extend(evaluate_transaction(txn, sg_config, "SG_MAS_Notice626"))
    alert_df = pd.DataFrame(rows, columns=ALERT_COLUMNS)
    return prepared, alert_df


transactions = read_csv(DATA_DIR / "synthetic_transactions.csv")
alerts = read_csv(DATA_DIR / "alert_results.csv")
fx_status = read_csv(DATA_DIR / "fx_rate_status.csv")
sanctions_status = read_csv(DATA_DIR / "sanctions_refresh_status.csv")
coverage = read_csv(DATA_DIR / "rules_ml_coverage.csv")
sensitivity = read_csv(DATA_DIR / "sensitivity_analysis.csv")
enforcement = read_csv(DATA_DIR / "public_enforcement_backtest.csv")
model_summary = read_json(DATA_DIR / "sanctions_source_summary.json")
us_config = read_json(CONFIG_DIR / "us_bsa_fincen.json")
sg_config = read_json(CONFIG_DIR / "sg_mas_notice626.json")


st.title("JurisCom AML/KYC Jurisdiction Demo")
st.caption("Standard Chartered scenario prototype | US BSA/FinCEN vs Singapore MAS Notice 626")
render_command_center()

if transactions.empty or alerts.empty:
    st.error("Generated data is missing. Run `python run_all.py` first.")
    st.stop()

total_alerts = len(alerts)
us_alerts = int((alerts["config_applied"] == "US_BSA_FinCEN").sum())
sg_alerts = int((alerts["config_applied"] == "SG_MAS_Notice626").sum())
unique_flagged = alerts["txn_id"].nunique()

cols = st.columns(4)
cols[0].metric("Transactions", len(transactions))
cols[1].metric("Generated alerts", total_alerts)
cols[2].metric("US alerts", us_alerts)
cols[3].metric("SG alerts", sg_alerts)

st.divider()

tab_txn, tab_ad_hoc, tab_triage, tab_sources, tab_evidence = st.tabs(
    ["Transaction explorer", "Ad hoc tester", "Analyst triage", "Source freshness", "Model evidence"]
)

with tab_txn:
    left, right = st.columns([0.35, 0.65])
    with left:
        search = st.text_input("Search transaction/customer/counterparty", "")
        filtered = filter_transactions(transactions, search)
        st.caption(f"{len(filtered)} of {len(transactions)} transactions match")
        if filtered.empty:
            st.warning("No transactions match the search.")
            txn_id = None
        else:
            label_map = {
                row["txn_id"]: transaction_label(row)
                for _, row in filtered.iterrows()
            }
            txn_id = st.selectbox(
                "Select transaction",
                filtered["txn_id"].tolist(),
                index=0,
                format_func=lambda value: label_map.get(value, value),
            )
        if txn_id:
            txn_row = transactions.loc[transactions["txn_id"] == txn_id].iloc[0]
            st.dataframe(
                txn_row.to_frame(name="value"),
                use_container_width=True,
            )
    with right:
        if txn_id:
            txn_alerts = alerts.loc[alerts["txn_id"] == txn_id].copy()
            us = txn_alerts.loc[txn_alerts["config_applied"] == "US_BSA_FinCEN"]
            sg = txn_alerts.loc[txn_alerts["config_applied"] == "SG_MAS_Notice626"]
            us_box, sg_box = st.columns(2)
            with us_box:
                st.subheader("US engine")
                st.write(format_alerts(us))
                if not us.empty:
                    st.dataframe(us[["alert_type", "reason", "rule_ref", "action_required"]], use_container_width=True, hide_index=True)
            with sg_box:
                st.subheader("Singapore engine")
                st.write(format_alerts(sg))
                if not sg.empty:
                    st.dataframe(sg[["alert_type", "reason", "rule_ref", "action_required"]], use_container_width=True, hide_index=True)

with tab_ad_hoc:
    st.subheader("Run additional transactions without editing the master CSV")
    st.caption(
        "Use this tab to test one-off scenarios or a temporary batch. Results are calculated in memory and do not change "
        "`Task3_data/synthetic_transactions.csv`."
    )

    with st.form("manual_transaction_form"):
        st.write("Manual transaction")
        c1, c2, c3, c4 = st.columns(4)
        txn_id = c1.text_input("Transaction ID", DEFAULT_TRANSACTION["txn_id"])
        txn_date = c2.date_input("Transaction date", value=pd.to_datetime(DEFAULT_TRANSACTION["txn_date"]).date())
        booking_entity = c3.selectbox("Booking entity", ["SCB_US", "SCB_SG"], index=1)
        txn_type = c4.selectbox("Transaction type", ["cash_deposit", "cash_withdrawal", "cash_exchange", "wire_transfer", "trade_finance"], index=3)

        c5, c6, c7, c8 = st.columns(4)
        currency = c5.selectbox("Currency", ["SGD", "USD", "EUR", "HKD"], index=0)
        amount_local = c6.number_input("Amount local", min_value=0.0, value=float(DEFAULT_TRANSACTION["amount_local"]), step=1000.0)
        suggested_usd = amount_local if currency == "USD" else amount_local * float(sg_config.get("fx_rate_to_usd", 0.743))
        amount_usd = c7.number_input("Amount USD equivalent", min_value=0.0, value=float(round(suggested_usd, 2)), step=1000.0)
        same_day_cumulative = c8.number_input("Same-day cumulative USD", min_value=0.0, value=float(round(max(suggested_usd, amount_usd), 2)), step=1000.0)

        c9, c10, c11, c12 = st.columns(4)
        customer_id = c9.text_input("Customer ID", DEFAULT_TRANSACTION["customer_id"])
        customer_name = c10.text_input("Customer name", DEFAULT_TRANSACTION["customer_name"])
        customer_type = c11.selectbox("Customer type", ["individual", "corporate"], index=0)
        customer_risk = c12.selectbox("Customer risk rating", ["low", "medium", "high"], index=1)

        c13, c14, c15, c16 = st.columns(4)
        pep_type = c13.selectbox("PEP type", ["none", "domestic", "foreign"], index=0)
        beneficial_owner_pct = c14.number_input("Beneficial owner %", min_value=0.0, max_value=100.0, value=0.0, step=5.0)
        beneficial_owner_disclosed = c15.checkbox("Beneficial owner disclosed", value=True)
        has_business_relationship = c16.checkbox("Existing business relationship", value=True)

        c17, c18, c19, c20 = st.columns(4)
        sanctions_list_hit = c17.selectbox("Sanctions list hit", ["none", "partial", "sdn", "ofac_sdn", "mas_tfs", "un_tfs", "un_designated"], index=0)
        sanctions_score = c18.slider("Sanctions match score %", min_value=0, max_value=100, value=0)
        is_sanctioned = c19.checkbox("Confirmed sanctioned party", value=False)
        suspicious_activity = c20.checkbox("Reason to suspect / suspicious activity", value=False)

        c21, c22, c23, c24 = st.columns(4)
        country_origin = c21.text_input("Customer origin country code", DEFAULT_TRANSACTION["country_of_origin"])
        counterparty_name = c22.text_input("Counterparty name", DEFAULT_TRANSACTION["counterparty_name"])
        counterparty_country = c23.text_input("Counterparty country code", DEFAULT_TRANSACTION["counterparty_country"])
        high_risk_country = c24.checkbox("High-risk country", value=False)

        unusual_notes = st.text_area("Unusual pattern notes", value=DEFAULT_TRANSACTION["unusual_pattern_notes"])
        purpose = st.text_input("Purpose of transaction", DEFAULT_TRANSACTION["purpose_of_txn"])
        structuring_flag = st.checkbox(
            "Manually mark structuring for this one-off test",
            value=False,
            help="For rolling-window structuring, use the temporary batch CSV tester below so the app has transaction history.",
        )
        run_manual = st.form_submit_button("Run ad hoc transaction")

    if run_manual:
        manual = pd.DataFrame([{
            "txn_id": txn_id,
            "booking_entity": booking_entity,
            "txn_date": txn_date.isoformat(),
            "txn_type": txn_type,
            "amount_local": amount_local,
            "currency": currency,
            "amount_usd": amount_usd,
            "customer_id": customer_id,
            "customer_name": customer_name,
            "customer_type": customer_type,
            "customer_risk_rating": customer_risk,
            "is_pep": pep_type != "none",
            "pep_type": pep_type,
            "is_sanctioned": is_sanctioned,
            "sanctions_list_hit": sanctions_list_hit,
            "sanctions_match_score_pct": sanctions_score,
            "beneficial_owner_pct": beneficial_owner_pct,
            "beneficial_owner_disclosed": beneficial_owner_disclosed,
            "country_of_origin": country_origin,
            "high_risk_country": high_risk_country,
            "counterparty_name": counterparty_name,
            "counterparty_country": counterparty_country,
            "same_day_cumulative_cash_usd": same_day_cumulative,
            "structuring_flag": structuring_flag,
            "unusual_pattern_notes": unusual_notes,
            "purpose_of_txn": purpose,
            "has_business_relationship": has_business_relationship,
            "suspicious_activity_flag": suspicious_activity,
        }])
        prepared, ad_hoc_alerts = evaluate_dataframe(manual, us_config, sg_config)
        st.write("Prepared transaction")
        st.dataframe(prepared.drop(columns=[c for c in prepared.columns if c.startswith("_")], errors="ignore"), use_container_width=True, hide_index=True)
        if ad_hoc_alerts.empty:
            st.success("No US or Singapore alerts were triggered for this ad hoc transaction.")
        else:
            st.write("Ad hoc alert result")
            st.dataframe(ad_hoc_alerts, use_container_width=True, hide_index=True)

    with st.expander("Batch-test temporary CSV rows"):
        st.caption(
            "Upload or paste a CSV with the same columns as `synthetic_transactions.csv`. Missing columns are filled with safe defaults. "
            "This also runs the rolling structuring detector on the temporary rows."
        )
        uploaded = st.file_uploader("Upload temporary transaction CSV", type=["csv"])
        pasted = st.text_area("Or paste CSV text", height=140, placeholder="txn_id,booking_entity,txn_date,txn_type,...")
        batch_df = pd.DataFrame()
        try:
            if uploaded is not None:
                batch_df = pd.read_csv(uploaded)
            elif pasted.strip():
                batch_df = pd.read_csv(StringIO(pasted))
        except Exception as exc:
            st.error(f"Could not read the temporary CSV: {exc}")
        if not batch_df.empty:
            prepared_batch, batch_alerts = evaluate_dataframe(batch_df, us_config, sg_config)
            st.write("Temporary rows after preparation")
            st.dataframe(prepared_batch, use_container_width=True, hide_index=True)
            st.write("Temporary batch alerts")
            if batch_alerts.empty:
                st.success("No alerts were triggered for the temporary batch.")
            else:
                st.dataframe(batch_alerts, use_container_width=True, hide_index=True)
                st.download_button(
                    "Download temporary alert CSV",
                    batch_alerts.to_csv(index=False).encode("utf-8"),
                    file_name="Task3_temporary_gui_alerts.csv",
                    mime="text/csv",
                )

with tab_triage:
    st.subheader("Analyst review queue")
    c1, c2, c3 = st.columns(3)
    jurisdiction_filter = c1.multiselect(
        "Jurisdiction",
        sorted(alerts["config_applied"].dropna().unique()),
        default=sorted(alerts["config_applied"].dropna().unique()),
    )
    alert_filter = c2.multiselect(
        "Alert type",
        sorted(alerts["alert_type"].dropna().unique()),
        default=sorted(alerts["alert_type"].dropna().unique()),
    )
    text_filter = c3.text_input("Reason contains", "")
    queue = alerts.loc[
        alerts["config_applied"].isin(jurisdiction_filter)
        & alerts["alert_type"].isin(alert_filter)
    ].copy()
    if text_filter:
        queue = queue.loc[queue["reason"].astype(str).str.contains(text_filter, case=False, na=False)]
    st.dataframe(
        queue[["txn_id", "config_applied", "alert_type", "reason", "rule_ref", "action_required"]],
        use_container_width=True,
        hide_index=True,
    )
    selected_alert = None
    if queue.empty:
        st.info("No alerts match the current filters.")
    else:
        selected_alert = st.selectbox("Open alert for disposition", queue.index.tolist())
    if selected_alert is not None:
        row = alerts.loc[selected_alert]
        st.write(f"**{row['txn_id']} | {row['config_applied']} | {row['alert_type']}**")
        disposition = st.radio(
            "Analyst disposition",
            ["Pending review", "Escalate to Compliance", "False positive", "File SAR/STR recommendation"],
            horizontal=True,
        )
        notes = st.text_area("Review note", placeholder="Record why this disposition was selected.")
        st.info(f"Prototype only: disposition is held in the Streamlit session. Selected: {disposition}")

with tab_sources:
    st.subheader("Data-source freshness")
    if not fx_status.empty:
        st.write("FX refresh")
        st.dataframe(fx_status, use_container_width=True, hide_index=True)
    if not sanctions_status.empty:
        st.write("Sanctions refresh")
        display = sanctions_status.copy()
        display["review_status"] = display["status"].map(status_badge)
        st.dataframe(
            display[
                [
                    "source_id",
                    "source_name",
                    "status",
                    "review_status",
                    "refresh_mode",
                    "checked_at",
                    "cache_modified_at",
                    "list_publish_date",
                    "record_count",
                    "cache_age_days",
                    "note",
                ]
            ],
            use_container_width=True,
            hide_index=True,
        )
    if model_summary:
        st.caption(model_summary.get("production_boundary", ""))

with tab_evidence:
    st.subheader("Public enforcement scenario simulation")
    if not enforcement.empty:
        st.dataframe(
            enforcement[
                [
                    "scenario_id",
                    "scenario_country",
                    "jurisdiction_tested",
                    "alert_types",
                    "surfaced_by_tool",
                    "limitation_note",
                ]
            ],
            use_container_width=True,
            hide_index=True,
        )
    st.subheader("Rules vs ML coverage")
    if not coverage.empty:
        st.dataframe(coverage, use_container_width=True, hide_index=True)
    st.subheader("Sensitivity analysis")
    if not sensitivity.empty:
        st.dataframe(sensitivity, use_container_width=True, hide_index=True)
    col_a, col_b = st.columns(2)
    with col_a:
        img = DATA_DIR / "shap_summary.png"
        if img.exists():
            st.image(str(img), caption="SHAP summary - anomaly drivers")
    with col_b:
        img = DATA_DIR / "shap_waterfall_anomaly.png"
        if img.exists():
            st.image(str(img), caption="SHAP waterfall - most anomalous transaction")

st.caption(
    "Boundary: this demo supports review and explanation. It does not automate SAR/STR filing, "
    "submit regulatory reports, or replace production sanctions/case-management systems."
)
