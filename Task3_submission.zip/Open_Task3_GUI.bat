@echo off
setlocal

cd /d "%~dp0"
set "APP_URL=http://localhost:8501"
set "PYTHON_EXE=python"

echo Starting Task 3 Streamlit GUI...
echo.
echo This window runs the local Python app. Keep it open while using the GUI.
echo Streamlit will open your browser automatically when ready.
echo If it does not, open: %APP_URL%
echo.

"%PYTHON_EXE%" -c "import streamlit" >nul 2>&1
if errorlevel 1 (
  echo Streamlit is not installed for %PYTHON_EXE%.
  echo Run this first:
  echo     "%PYTHON_EXE%" -m pip install -r Task3_requirements.txt
  echo.
  pause
  exit /b 1
)

"%PYTHON_EXE%" -m streamlit run Task3_streamlit_app.py --server.port 8501 --browser.gatherUsageStats false

pause
