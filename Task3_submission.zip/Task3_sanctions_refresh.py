"""Refresh public sanctions-list source files with cache and freshness status.

This is a prototype data-ingestion control, not a production sanctions
screening engine. It downloads public OFAC SDN XML and UN Consolidated XML,
keeps a local cache, writes a status CSV, and records a compact summary for
the model card / demo UI.

Run:
    python Task3_sanctions_refresh.py
    python Task3_sanctions_refresh.py --force
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET


BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "Task3_config" / "sanctions_sources.json"
USER_AGENT = "JurisCom-RegTech-Prototype/0.1"


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return utc_now().isoformat(timespec="seconds").replace("+00:00", "Z")


def load_config() -> dict[str, Any]:
    with open(CONFIG_PATH, encoding="utf-8") as f:
        return json.load(f)


def local_path(config: dict[str, Any], key: str) -> Path:
    return BASE_DIR / config["refresh_policy"][key]


def file_age_days(path: Path) -> float | None:
    if not path.exists():
        return None
    age_seconds = utc_now().timestamp() - path.stat().st_mtime
    return max(age_seconds / 86400, 0.0)


def sha256_prefix(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


def fetch_url(url: str, target: Path) -> tuple[bool, str]:
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(target.suffix + ".tmp")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=90) as response:
            tmp.write_bytes(response.read())
        if tmp.stat().st_size <= 0:
            raise ValueError("downloaded file is empty")
        tmp.replace(target)
        return True, "online"
    except Exception as exc:
        if tmp.exists():
            tmp.unlink()
        return False, f"cache_fallback: {exc}"


def strip_ns(tag: str) -> str:
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def first_child_text(node: ET.Element, name: str) -> str:
    for child in node:
        if strip_ns(child.tag) == name and child.text:
            return child.text.strip()
    return ""


def parse_ofac(path: Path) -> dict[str, Any]:
    root = ET.parse(path).getroot()
    publish_info = next((c for c in root if strip_ns(c.tag) == "publshInformation"), None)
    record_count = len([c for c in root if strip_ns(c.tag) == "sdnEntry"])
    publish_date = ""
    declared_count = ""
    if publish_info is not None:
        publish_date = first_child_text(publish_info, "Publish_Date")
        declared_count = first_child_text(publish_info, "Record_Count")
    return {
        "list_publish_date": publish_date,
        "record_count": int(declared_count or record_count),
        "individual_count": "",
        "entity_count": "",
        "xml_root": strip_ns(root.tag),
    }


def parse_un(path: Path) -> dict[str, Any]:
    root = ET.parse(path).getroot()
    individuals = len(root.findall(".//INDIVIDUAL"))
    entities = len(root.findall(".//ENTITY"))
    return {
        "list_publish_date": root.attrib.get("dateGenerated", ""),
        "record_count": individuals + entities,
        "individual_count": individuals,
        "entity_count": entities,
        "xml_root": strip_ns(root.tag),
    }


def parse_mas_tfs(path: Path) -> dict[str, Any]:
    """Best-effort scrape of the MAS TFS landing page for circular titles, dates, and PDF links.

    Goal is to surface the *existence* and dates of recent MAS sanctions circulars so a
    stale landing page becomes visible. PDF body parsing remains a manual legal/compliance
    step — this function only reads anchor tags and dates from the cached HTML.

    Honest diagnostic: the MAS landing page is JavaScript-rendered. Static HTML fetches
    return navigation chrome only, so a 0-entry result is itself a meaningful signal that
    automated extraction has reached its limit and a headless browser or licensed feed
    (Refinitiv, Dow Jones, ComplyAdvantage) is required for production use.
    """
    html = path.read_text(encoding="utf-8", errors="replace")
    html_size_bytes = len(html)
    total_anchors = len(re.findall(r"<a\b", html, flags=re.IGNORECASE))
    total_scripts = len(re.findall(r"<script\b", html, flags=re.IGNORECASE))
    title_match = re.search(r"<title[^>]*>([^<]*)</title>", html, flags=re.IGNORECASE)
    page_title = (title_match.group(1).strip() if title_match else "")
    page_title_low = page_title.lower()
    is_maintenance_page = any(
        marker in page_title_low for marker in ("maintenance", "service unavailable", "error", "not found")
    )

    anchor_re = re.compile(r'<a[^>]+href="([^"#?]+)"[^>]*>(.*?)</a>', re.IGNORECASE | re.DOTALL)
    date_long = re.compile(
        r'(\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-zA-Z]*\s+\d{4})',
        re.IGNORECASE,
    )
    date_iso = re.compile(r'(\d{4}-\d{2}-\d{2})')
    keywords = (
        "sanction", "tfs", "designation", "circular", "directive",
        "asset freeze", "regulation", "un security council", "1267", "1373",
    )

    candidates: list[dict[str, Any]] = []
    for href, raw_text in anchor_re.findall(html):
        text = re.sub(r"<[^>]+>", " ", raw_text)
        text = re.sub(r"\s+", " ", text).strip()
        if not text:
            continue
        href_low = href.lower()
        text_low = text.lower()
        is_pdf = href_low.endswith(".pdf")
        if not (is_pdf or any(k in text_low for k in keywords) or any(k in href_low for k in keywords)):
            continue
        m = date_long.search(text) or date_iso.search(text)
        date = m.group(1) if m else ""
        if href.startswith("/"):
            href = "https://www.mas.gov.sg" + href
        candidates.append({
            "title": text[:200],
            "url": href,
            "date": date,
            "is_pdf": is_pdf,
        })

    seen: set[str] = set()
    unique: list[dict[str, Any]] = []
    for entry in candidates:
        if entry["url"] in seen:
            continue
        seen.add(entry["url"])
        unique.append(entry)

    pdf_count = sum(1 for e in unique if e["is_pdf"])
    dated_count = sum(1 for e in unique if e["date"])

    # Last-known-good snapshot lookup (for fallback when current run returns 0 entries)
    last_good_path = path.parent / "mas_tfs_index_last_good.json"
    last_good_age_days: float | None = None
    last_good_entry_count: int | None = None
    last_good_captured_at: str = ""
    if last_good_path.exists():
        try:
            last_good_payload = json.loads(last_good_path.read_text(encoding="utf-8"))
            last_good_entry_count = int(last_good_payload.get("entry_count", 0))
            last_good_captured_at = str(last_good_payload.get("captured_at", ""))
        except Exception:
            last_good_entry_count = None
        last_good_age_days = round(
            max(0.0, (utc_now().timestamp() - last_good_path.stat().st_mtime) / 86400),
            2,
        )

    last_good_suffix = ""
    if last_good_age_days is not None and last_good_entry_count:
        last_good_suffix = (
            f" Last-known-good capture: {last_good_entry_count} entries, "
            f"{last_good_age_days} days old (see mas_tfs_index_last_good.json)."
        )

    likely_js_rendered = (
        len(unique) == 0 and total_anchors < 30 and total_scripts >= 1 and not is_maintenance_page
    )
    if is_maintenance_page:
        diagnostic = (
            f"MAINTENANCE_OR_ERROR_PAGE: page title is '{page_title}'. "
            "MAS may be in a maintenance window or the URL may have moved. "
            "This is exactly the freshness signal the scraper exists to surface — "
            "a human compliance reviewer should check the live MAS TFS page."
            + last_good_suffix
        )
        status_hint = "MAINTENANCE_PAGE_DETECTED"
    elif likely_js_rendered:
        diagnostic = (
            "PAGE_IS_JS_RENDERED: static HTML returned only navigation chrome "
            f"({total_anchors} total anchors, {total_scripts} <script> tags, "
            f"{html_size_bytes:,} bytes). Production needs a headless browser "
            "(Playwright/Selenium) or a licensed feed (Refinitiv, Dow Jones, "
            "ComplyAdvantage) to extract circular bodies. The scraper still serves "
            "as a freshness-of-page hash control."
            + last_good_suffix
        )
        status_hint = "PARTIAL_AUTOMATION"
    elif len(unique) == 0:
        diagnostic = (
            "ZERO_MATCHES: the page parsed cleanly but no anchors matched the sanctions "
            "keyword filter. Verify the page URL or expand the keyword set."
            + last_good_suffix
        )
        status_hint = "PARTIAL_AUTOMATION"
    else:
        diagnostic = f"FOUND_ENTRIES: {len(unique)} sanctions-related anchors, {pdf_count} PDF links, {dated_count} dated."
        status_hint = ""

    index_payload: dict[str, Any] = {
        "generated_at": iso_now(),
        "source_url": "https://www.mas.gov.sg/regulation/anti-money-laundering/targeted-financial-sanctions",
        "entry_count": len(unique),
        "pdf_count": pdf_count,
        "dated_count": dated_count,
        "entries": unique[:100],
        "page_diagnostics": {
            "html_size_bytes": html_size_bytes,
            "total_anchors": total_anchors,
            "total_scripts": total_scripts,
            "page_title": page_title,
            "is_maintenance_page": is_maintenance_page,
            "likely_js_rendered": likely_js_rendered,
            "diagnostic": diagnostic,
        },
        "last_known_good": {
            "exists": last_good_age_days is not None,
            "captured_at": last_good_captured_at,
            "age_days": last_good_age_days,
            "entry_count": last_good_entry_count,
            "path": "Task3_data/sanctions_cache/mas_tfs_index_last_good.json",
        },
        "note": (
            "Best-effort extraction of MAS TFS landing-page anchors mentioning sanctions, "
            "TFS, designations, circulars, asset-freeze, or UN Security Council. "
            "Existence + date metadata only — PDF body parsing remains manual legal review. "
            "When a run returns >0 entries the payload is also copied to "
            "mas_tfs_index_last_good.json so reviewers always have a baseline to compare against."
        ),
    }
    index_path = path.parent / "mas_tfs_index.json"
    index_path.write_text(json.dumps(index_payload, indent=2), encoding="utf-8")

    # Preserve last-known-good snapshot only when we actually got entries.
    # If a future run returns 0 entries (maintenance window, layout change),
    # the previous good snapshot remains untouched as a comparison baseline.
    if len(unique) > 0:
        last_good_payload = dict(index_payload)
        last_good_payload["captured_at"] = iso_now()
        last_good_payload["note"] = (
            "Last successful (entries > 0) capture of the MAS TFS landing page. "
            "Auto-preserved by Task3_sanctions_refresh.py whenever a run produces >0 entries; "
            "left untouched on subsequent zero-entry runs (maintenance windows, layout changes). "
            "Compare against mas_tfs_index.json to see what has changed."
        )
        last_good_path.write_text(json.dumps(last_good_payload, indent=2), encoding="utf-8")

    return {
        "list_publish_date": "",
        "record_count": len(unique),
        "individual_count": pdf_count,
        "entity_count": dated_count,
        "xml_root": "html",
        "_status_hint": status_hint,
        "_diagnostic": diagnostic,
    }


def parse_source(path: Path, parser_name: str) -> dict[str, Any]:
    if parser_name == "ofac_legacy_sdn_xml":
        return parse_ofac(path)
    if parser_name == "un_consolidated_xml":
        return parse_un(path)
    if parser_name == "mas_tfs_circular_index":
        return parse_mas_tfs(path)
    return {
        "list_publish_date": "",
        "record_count": "",
        "individual_count": "",
        "entity_count": "",
        "xml_root": "",
    }


def refresh_source(
    source_id: str,
    source: dict[str, Any],
    config: dict[str, Any],
    *,
    force: bool = False,
) -> dict[str, Any]:
    stale_after = int(source.get("stale_after_days") or config["refresh_policy"].get("default_stale_after_days", 1))
    cache_dir = local_path(config, "cache_directory")
    cache_file = source.get("cache_file")
    cache_path = cache_dir / cache_file if cache_file else None

    base_row: dict[str, Any] = {
        "source_id": source_id,
        "source_name": source.get("source_name", source_id),
        "jurisdiction": source.get("jurisdiction", ""),
        "enabled": bool(source.get("enabled")),
        "status": "NOT_CONFIGURED",
        "refresh_mode": "",
        "source_url": source.get("url") or "",
        "official_page": source.get("official_page") or "",
        "cache_file": cache_path.relative_to(BASE_DIR).as_posix() if cache_path else "",
        "checked_at": "",
        "cache_modified_at": "",
        "cache_age_days": "",
        "stale_after_days": stale_after,
        "list_publish_date": "",
        "record_count": "",
        "individual_count": "",
        "entity_count": "",
        "sha256_prefix": "",
        "note": source.get("notes", ""),
    }

    if not source.get("enabled"):
        base_row["status"] = "MANUAL_LIMITATION"
        base_row["refresh_mode"] = "manual"
        return base_row

    if cache_path is None:
        base_row["status"] = "ERROR"
        base_row["note"] = "Enabled source has no cache_file configured"
        return base_row

    age = file_age_days(cache_path)
    needs_refresh = force or age is None or age >= stale_after
    mode = "cache"
    if needs_refresh:
        ok, mode = fetch_url(source["url"], cache_path)
        if not ok and not cache_path.exists():
            base_row["status"] = "ERROR"
            base_row["refresh_mode"] = mode
            return base_row

    age = file_age_days(cache_path)
    status = "OK"
    if age is not None and age >= stale_after:
        status = "STALE"

    try:
        parsed = parse_source(cache_path, source.get("parser", ""))
    except Exception as exc:
        base_row["status"] = "PARSE_ERROR"
        base_row["refresh_mode"] = mode
        base_row["note"] = f"{source.get('notes', '')} Parse failed: {exc}"
        return base_row

    status_hint = parsed.pop("_status_hint", "") if isinstance(parsed, dict) else ""
    diagnostic = parsed.pop("_diagnostic", "") if isinstance(parsed, dict) else ""

    base_row.update(parsed)
    base_row["status"] = status_hint or status
    base_row["refresh_mode"] = mode
    base_row["checked_at"] = iso_now()
    base_row["cache_modified_at"] = datetime.fromtimestamp(
        cache_path.stat().st_mtime, tz=timezone.utc
    ).isoformat(timespec="seconds").replace("+00:00", "Z")
    base_row["cache_age_days"] = round(age or 0, 3)
    base_row["sha256_prefix"] = sha256_prefix(cache_path)
    if diagnostic:
        existing = base_row.get("note", "") or ""
        base_row["note"] = (existing + " | " + diagnostic).strip(" |")
    return base_row


def write_status(rows: list[dict[str, Any]], config: dict[str, Any]) -> None:
    status_path = local_path(config, "status_file")
    status_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "source_id",
        "source_name",
        "jurisdiction",
        "enabled",
        "status",
        "refresh_mode",
        "source_url",
        "official_page",
        "cache_file",
        "checked_at",
        "cache_modified_at",
        "cache_age_days",
        "stale_after_days",
        "list_publish_date",
        "record_count",
        "individual_count",
        "entity_count",
        "xml_root",
        "sha256_prefix",
        "note",
    ]
    with status_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

    summary_path = local_path(config, "summary_file")
    summary = {
        "generated_at": iso_now(),
        "sources": rows,
        "production_boundary": (
            "OFAC and UN XML are refreshed and cached as full lists. MAS TFS now has a best-effort "
            "landing-page scraper that records circular titles, dates, and PDF links into "
            "mas_tfs_index.json — surfaces freshness of the MAS designations page but does NOT parse "
            "PDF bodies. Production would still need a licensed/official MAS feed or vendor "
            "(Refinitiv / Dow Jones / ComplyAdvantage) plus formal legal-operations workflow for PDF review."
        ),
    }
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--force", action="store_true", help="Refresh even when cache is still fresh.")
    args = parser.parse_args()

    config = load_config()
    rows = [
        refresh_source(source_id, source, config, force=args.force)
        for source_id, source in config.get("sources", {}).items()
    ]
    write_status(rows, config)

    print("Sanctions refresh status:")
    for row in rows:
        count = row.get("record_count", "")
        suffix = f"; records={count}" if count != "" else ""
        print(f"  {row['source_id']}: {row['status']} ({row['refresh_mode']}){suffix}")
    print(f"Wrote {config['refresh_policy']['status_file']}")
    print(f"Wrote {config['refresh_policy']['summary_file']}")
    if any(row["status"] in {"ERROR", "PARSE_ERROR"} for row in rows):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
