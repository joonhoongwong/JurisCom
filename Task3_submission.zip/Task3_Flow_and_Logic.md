# Task 3 — Flow and Logic
**JurisCom RegTech: jurisdiction-aware AML/KYC compliance prototype**
*A walkthrough of how a transaction passes through the engine, what each layer does, and where humans must intervene.*

---

## 1. The 3-layer architecture

The tool is built in three layers. Every transaction passes top-to-bottom. The point of the design is that **only Layer 2 changes when a regulation changes** — Layer 1 (data) and Layer 3 (engine code) do not need to be modified.

```
┌─────────────────────────────────────────────────────────────────┐
│  LAYER 1 — Inputs (existing bank data, refreshed sources)       │
│  • synthetic_transactions.csv (42 transactions across US + SG) │
│  • fx_rates.json (live SGD/USD from Frankfurter API)           │
│  • OFAC SDN XML / UN Consolidated XML (daily refresh)          │
│  • MAS TFS landing-page scrape (weekly, fallback to last-good) │
└──────────────────────────────┬──────────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────────┐
│  LAYER 2 — Jurisdiction config (the swappable rules)           │
│  Task3_config/                                                  │
│   ├─ us_bsa_fincen.json   (BSA, FinCEN CTR/SAR, OFAC, etc.)    │
│   ├─ sg_mas_notice626.json (MAS Notice 626 STR, CDD, PEP, etc.)│
│   ├─ fx_rates.json (rate + staleness window)                   │
│   └─ sanctions_sources.json (which lists to refresh and how)   │
│                                                                 │
│  Each config carries: thresholds, applicability flags,         │
│  filing forms, statutory rule references, regulator name.       │
└──────────────────────────────┬──────────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────────┐
│  LAYER 3 — Engine + ML augmentation + outputs                  │
│  Task3_verify_notebook.py:                                      │
│   ├─ StructuringDetector  (per-customer 7-day rolling window)  │
│   ├─ JurisdictionAlertEngine (7 alert types per config)        │
│   ├─ IsolationForest       (anomaly score, contamination 0.15) │
│   └─ SHAP Explainer        (per-feature attribution)           │
│                                                                 │
│  Outputs:                                                       │
│   • alert_results.csv (every alert, every txn × every config)  │
│   • iforest_results.csv + shap_summary.png + waterfall.png     │
│   • sensitivity_analysis.csv (contamination + lookback sweeps) │
│   • public_enforcement_backtest.csv (5 SCB-style scenarios)    │
│   • rules_ml_coverage.csv (rules-only vs ML-only vs both)      │
│   • fx_rate_status.csv + sanctions_refresh_status.csv          │
└─────────────────────────────────────────────────────────────────┘
```

The principle: **add a new jurisdiction = add one JSON file**. No engine changes, no software release, no code review of business logic.

---

## 2. End-to-end data flow (numbered)

Every time `python run_all.py` is executed, the following sequence happens. Each step has a corresponding artifact you can inspect.

| Step | What happens | Artifact / output |
|---|---|---|
| 1 | The synthetic transaction CSV is loaded into a pandas DataFrame. Field types are coerced (numerics → float, booleans → bool). | `Task3_data/synthetic_transactions.csv` (42 rows) |
| 2 | The FX refresh module fetches today's SGD/USD rate from a public Frankfurter API. If the API is unavailable, the cached `fx_rates.json` value is used. The age of the rate is recorded. | `Task3_config/fx_rates.json`, `Task3_data/fx_rate_status.csv` |
| 3 | The sanctions refresh module fetches OFAC SDN (XML), UN Consolidated (XML), and the MAS TFS landing page (HTML). Each cache file gets a SHA-256 prefix and a freshness timestamp. The MAS scraper sets `MAINTENANCE_PAGE_DETECTED` if the page title contains "maintenance" / "error" / "service unavailable", and preserves the last-known-good index. | `Task3_data/sanctions_cache/*`, `Task3_data/sanctions_refresh_status.csv` |
| 4 | The `StructuringDetector` runs once per jurisdiction. It groups cash transactions by customer and slides a 7-day window across each customer's history. If 3 or more cash transactions in any window each fall below the local CTR/CDD threshold AND their sum reaches the threshold, every contributing transaction is flagged. The result is added as `computed_structuring_us` and `computed_structuring_sg` columns on the DataFrame. | Two new boolean columns in memory; flags are then read by the alert engine in step 5 |
| 5 | For every transaction, the `JurisdictionAlertEngine` runs all seven rule checks against **both** the US config and the SG config independently. Order: SANCTIONS_BLOCK → CTR → CDD_ONE_OFF → SAR/STR → EDD_PEP → BO_FLAG. Each alert carries `txn_id`, `jurisdiction`, `alert_type`, `reason`, `rule_ref`, `action_required`, and (where applicable) `filing_deadline`. | `Task3_data/alert_results.csv` |
| 6 | The IsolationForest model is trained on the 42-transaction feature matrix (amount, sanctions match score, BO %, structuring flags, txn type code, risk rating). Contamination is set to 0.15 → the model flags ~15% of transactions as anomalous. | `Task3_data/isolation_forest_results.csv` (43 rows: 1 header + 42 txns with `iforest_score` + `iforest_anomaly`) |
| 7 | SHAP TreeExplainer produces (a) a global feature-importance summary plot and (b) a per-transaction waterfall plot for the most-anomalous transaction (lowest `iforest_score`). | `Task3_data/shap_summary.png`, `Task3_data/shap_waterfall_anomaly.png`, `Task3_data/shap_feature_importance.csv`, `Task3_data/shap_waterfall_values.csv` |
| 8 | A sensitivity sweep varies (a) IsolationForest contamination across 0.05 / 0.10 / 0.15 / 0.20 and (b) structuring lookback across 3 / 5 / 7 / 14 days. Alert and anomaly counts are recorded for each combination. | `Task3_data/sensitivity_analysis.csv` |
| 9 | A rules-vs-ML coverage table is produced: how many transactions are flagged by rules only, ML only, or both. | `Task3_data/rules_ml_coverage.csv` |
| 10 | A public-enforcement back-test runs five synthetic SCB-style scenarios (Iran, Myanmar, Syria, Sudan, Zimbabwe) through the engine and records whether each fact pattern surfaces under each jurisdiction. | `Task3_data/public_enforcement_backtest.csv` |
| 11 | 38 verification checks run: 4 differential cases + 29 trigger-coverage checks + 9 structuring-detector checks. The script raises an AssertionError if any check fails. | stdout output `ALL TRIGGER COVERAGE CHECKS PASSED` etc. |
| 12 | `run_all.py` rebuilds the notebook wrapper from the verifier output and creates the final submission zip. | `Task3_notebook.ipynb`, `Task3_submission.zip` |

---

## 3. Decision logic per alert type

### 3.1 SANCTIONS_BLOCK (both jurisdictions)
```
IF customer.is_sanctioned == True
   OR sanctions_list_hit IN {SDN, MAS_TFS, UN_TFS, OFAC_SDN, UN_DESIGNATED}
   OR sanctions_match_score_pct ≥ jurisdiction.match_threshold_pct
THEN
   alert: SANCTIONS_BLOCK
   action: BLOCK transaction + file STR/SAR + escalate
   reviewer: Senior AML analyst + Compliance sign-off
```
US match threshold = 85%, SG match threshold = 80% (stricter due to transliteration handling).

### 3.2 CTR (US only)
```
IF txn.txn_type IN {cash_deposit, cash_withdrawal, cash_exchange}
   AND same_day_cumulative_cash_usd ≥ 10,000
THEN
   alert: CTR
   action: File FinCEN Form 112 within 15 calendar days
   reviewer: Technology auto-files; Compliance spot-checks
```
SG config has `ctr.enabled = false` because MAS Notice 626 for banks does not have a US-style CTR analogue.

### 3.3 CDD_ONE_OFF (SG only)
```
IF txn.has_business_relationship == False
   AND txn.txn_type IN {cash_deposit, cash_withdrawal, cash_exchange, wire_transfer}
   AND amount_local ≥ SGD 20,000
THEN
   alert: CDD_ONE_OFF
   action: Perform and document CDD for non-account-holder transaction
   reviewer: KYC analyst
```

### 3.4 SAR (US, threshold-based + suspicion)
```
IF max(amount_usd, same_day_cumulative_cash_usd) ≥ 5,000
   AND (computed_structuring_us
        OR sanctions partial/fuzzy match
        OR suspicious_activity_flag == True)
THEN
   alert: SAR
   action: File FinCEN Form 111 within 30 calendar days; no tipping off
   reviewer: AML analyst + Compliance escalation for borderline cases
```

### 3.5 STR (SG, purely risk-based — no monetary threshold)
```
IF computed_structuring_sg
   OR high_risk_country == True
   OR sanctions partial/fuzzy match (without exact list hit)
   OR unusual_pattern_notes is non-empty
THEN
   alert: STR
   action: File STR with STRO as soon as practicable; no tipping off
   reviewer: AML analyst + Compliance
```
This is the philosophical divergence from the US — no monetary floor.

### 3.6 EDD_PEP (PEP enhanced due diligence)
```
IF customer.pep_type == "domestic" AND jurisdiction.domestic_pep_enhanced_dd == True
   OR customer.pep_type == "foreign" AND jurisdiction.foreign_pep_enhanced_dd == True
THEN
   alert: EDD_PEP
   action: Initiate EDD; collect source of wealth
   reviewer: Relationship Manager + Compliance
```
US: `domestic_pep_enhanced_dd = false`, `foreign_pep_enhanced_dd = true`.
SG: both flags `true` plus senior-management approval required.

### 3.7 BO_FLAG (Beneficial Ownership)
```
US (bright-line):
   IF customer_type == "corporate"
      AND beneficial_owner_pct ≥ 25
      AND beneficial_owner_disclosed == False
   THEN BO_FLAG

SG (reasonable measures):
   IF customer_type == "corporate"
      AND beneficial_owner_disclosed == False
   THEN BO_FLAG (any undisclosed corporate, regardless of percentage)
```
This is why the 24.9%-UBO case (TXN-US-011) triggers under SG but not US.

---

## 4. Multi-jurisdiction conflict (deliberately not auto-resolved)

When a transaction is touched by both US and SG configs, the engine produces **two independent alert sets**. The bank's policy chooses precedence — the tool surfaces the conflict but does not resolve it. Three documented policy options (Slide 11 of the deck, Task 4 Q4):

| Policy | Mechanism |
|---|---|
| Booking-entity-wins | Apply the rules of the legal entity that booked the transaction |
| Most-restrictive-rule | Trigger if any jurisdiction's rule fires; do not file twice for the same conduct |
| Counterparty-touches | If a counterparty country triggers another regime's STR/EDD, file under that regime |

The principle: precedence is a **bank-policy decision**, not a vendor decision. A vendor default could be read as the bank ceding judgement to a vendor, which the assignment's "judgement cannot be outsourced" framing explicitly rejects.

---

## 5. Worked example — TXN-SG-007 end-to-end

This is the headline jurisdiction-divergence case. Trace it through Layers 1 → 2 → 3.

### Input data (Layer 1)
```
txn_id:                TXN-SG-007
booking_entity:        SCB_SG
txn_date:              2024-11-26
txn_type:              trade_finance
amount_local:          3,000 SGD
amount_usd:            2,229 USD
customer_id:           CUST-011 (Pacific Bridge Ltd, corporate, high-risk rating)
counterparty_country:  MM (Myanmar)
high_risk_country:     True
is_pep:                False
is_sanctioned:         False
sanctions_list_hit:    none
beneficial_owner_pct:  40
beneficial_owner_disclosed: True
suspicious_activity_flag:   False
```

### Engine pass against US config (Layer 2 + 3)

| Check | Result | Why |
|---|---|---|
| SANCTIONS_BLOCK | NO | No list hit, no fuzzy match, not flagged |
| CTR | NO | Not a cash transaction (txn_type is `trade_finance`) |
| CDD_ONE_OFF | n/a | US config has CDD_ONE_OFF disabled |
| SAR | **NO** | `amount_usd 2,229 < SAR floor 5,000`. The reason-to-suspect is real (Myanmar high-risk), but the floor is a hard precondition under US rules |
| EDD_PEP | NO | Customer is not a PEP |
| BO_FLAG | NO | BO disclosed at 40% |

**US engine output:** zero alerts. The transaction passes silently.

### Engine pass against SG config (same data, different rules)

| Check | Result | Why |
|---|---|---|
| SANCTIONS_BLOCK | NO | No list hit |
| CTR | n/a | SG config has CTR disabled |
| CDD_ONE_OFF | NO | Customer has business relationship |
| **STR** | **YES** | SG STR is risk-based with no monetary threshold. `high_risk_country == True` (Myanmar) is a sufficient trigger |
| EDD_PEP | NO | Not a PEP |
| BO_FLAG | NO | BO disclosed |

**SG engine output:**
```
alert_type:       STR
reason:           Risk-based STR: high-risk country (MM)
rule_ref:         MAS Notice 626 - STR (STRO)
action_required:  File STR with STRO as soon as practicable; no tipping off
filing_deadline:  (none — "as soon as practicable")
```

### What the divergence means in practice
A bank that only ran the US config on its global transaction feed would never see this transaction. A bank that ran both configs in parallel sees both outcomes side-by-side and can apply its own conflict-resolution policy (Section 4 above).

### What the ML layer says about this transaction
TXN-SG-007 is not the most-anomalous row by IsolationForest score — TXN-US-005 (a USD 75,000 wire to a sanctioned counterparty) is. But TXN-SG-007 does receive a moderately negative anomaly score because of the high-risk-country feature. SHAP would attribute that score primarily to `high_risk_country == 1` and the small `amount_usd`. The point: **ML confirms the rules engine, it does not replace it**. The legal trigger is the SG STR rule; the IsolationForest score is supporting evidence for analyst prioritisation.

### Where humans must intervene before any action
Before SCB Singapore actually files an STR with STRO based on this alert:
1. An AML analyst reviews the transaction context (is the Pacific Bridge Ltd customer a known garment exporter with legitimate Myanmar trade? Or is this their first Myanmar transaction?)
2. The analyst checks for any whitelist or business-relationship exception
3. Compliance sign-off is required for the filing decision
4. The decision (file / do not file / escalate) is recorded in the alert disposition log
5. Tipping-off the customer is prohibited under MAS rules

The tool does **not** automate any of these steps. It produces structured evidence; humans decide.

---

## 6. Where humans must intervene (general matrix)

| Decision | Why the tool does not automate it | Who decides |
|---|---|---|
| SAR / STR filing decision | Statutory judgement; tipping-off liability; legal-privilege concerns | AML analyst + Compliance |
| SANCTIONS_BLOCK customer action | Wrongful blocking is itself a regulatory failure; need senior approval | Senior AML analyst + Compliance |
| PEP source-of-wealth gathering | Requires customer interaction and document review | Relationship Manager + Compliance |
| Multi-jurisdiction precedence | Bank-specific policy; differs across institutions | Bank's CCO writes the policy once; tool applies it |
| MAS TFS PDF body interpretation | MAS publishes designations as PDFs and JS-rendered web content; reliable parsing requires legal review or a licensed vendor feed | Compliance team or licensed feed (Refinitiv / Dow Jones / ComplyAdvantage) |
| Stale-FX warning resolution | Whether to refresh or proceed depends on operational context | Risk team |
| Borderline anomaly review | A SHAP score is informative but not dispositive | AML analyst |

The principle threaded through all of these: **the tool produces structured evidence with rule references; humans make the legal decision.**

---

## 7. What the marker can verify in 60 seconds

If the marker has 60 seconds, here is the fastest path to verifying that everything in this document actually works:

1. Run `python run_all.py` from `aml_kyc/`. It should print `ALL 4 DIFFERENTIAL CASES VERIFIED`, `ALL TRIGGER COVERAGE CHECKS PASSED` (29 checks), `ALL STRUCTURING CHECKS PASSED` (9 checks), and write the submission zip.
2. Open `Task3_data/alert_results.csv` and search for `TXN-SG-007`. There should be a single SG STR row with `reason: Risk-based STR: high-risk country (MM)`. There should be no US row for that transaction.
3. Open `Task3_data/shap_waterfall_anomaly.png`. The most-anomalous transaction is labelled and its top 3 contributing features are visible.
4. Open `Task3_data/sanctions_refresh_status.csv`. Three rows: `ofac_sdn: OK`, `un_consolidated: OK`, `mas_tfs: MAINTENANCE_PAGE_DETECTED` (or `OK` if MAS is back online).

Any one of those failing is grounds for asking a question. All four passing is the engine working as documented.
