"""Rebuild and package the Task 3 AML/KYC prototype.

Run from this folder:
    python run_all.py

This script is intentionally Task 3-only. It refreshes the public source
status files, runs the verifier/checklist, rebuilds the notebook wrapper, and
creates a clean submission zip from the files that actually exist here.
"""
from __future__ import annotations

import base64
import json
import os
import subprocess
import sys
import zipfile
from datetime import datetime
from pathlib import Path

import pandas as pd


BASE_DIR = Path(__file__).resolve().parent
ZIP_PATH = BASE_DIR / "Task3_submission.zip"

ROOT_FILES = [
    "README.md",
    "Open_Task3_GUI.bat",
    "run_all.py",
    "Task3_Flow_and_Logic.md",
    "Task3_model_card.md",
    "Task3_notebook.ipynb",
    "Task3_requirements.txt",
    "Task3_sanctions_refresh.py",
    "Task3_streamlit_app.py",
    "Task3_summary.md",
    "Task3_verify_notebook.py",
]

DATA_ARTIFACTS_EXPECTED = [
    "alert_results.csv",
    "fx_rate_status.csv",
    "isolation_forest_results.csv",
    "public_enforcement_backtest.csv",
    "rules_ml_coverage.csv",
    "sanctions_refresh_status.csv",
    "sanctions_source_summary.json",
    "sensitivity_analysis.csv",
    "shap_feature_importance.csv",
    "shap_summary.png",
    "shap_waterfall_anomaly.png",
    "shap_waterfall_values.csv",
    "synthetic_transactions.csv",
    "threshold_comparison.png",
]


def log(message: str) -> None:
    print(f"[run_all] {message}")


def run_python(script_name: str, *, capture: bool = False) -> str:
    script = BASE_DIR / script_name
    if not script.exists():
        raise FileNotFoundError(f"Missing required script: {script_name}")

    cmd = [sys.executable, str(script)]
    log(f"running: {' '.join(cmd)}")
    result = subprocess.run(
        cmd,
        cwd=str(BASE_DIR),
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=capture,
        env={**os.environ, "PYTHONUTF8": "1"},
    )
    if capture:
        if result.stdout:
            print(result.stdout, end="")
        if result.stderr:
            print(result.stderr, end="", file=sys.stderr)
    if result.returncode != 0:
        raise RuntimeError(f"{script_name} failed with exit code {result.returncode}")
    return result.stdout if capture else ""


def _md(text: str) -> dict:
    return {
        "cell_type": "markdown",
        "metadata": {},
        "source": text.splitlines(keepends=True),
    }


def _code(source: str, outputs: list[dict] | None = None) -> dict:
    return {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": outputs or [],
        "source": source.splitlines(keepends=True),
    }


def _stream(text: str) -> dict:
    return {"name": "stdout", "output_type": "stream", "text": text.splitlines(keepends=True)}


def _df_output(df: pd.DataFrame) -> dict:
    return {
        "output_type": "execute_result",
        "execution_count": None,
        "metadata": {},
        "data": {
            "text/plain": df.to_string().splitlines(keepends=True),
            "text/html": df.to_html().splitlines(keepends=True),
        },
    }


def _image_output(png_path: Path) -> dict:
    b64 = base64.b64encode(png_path.read_bytes()).decode("ascii")
    return {
        "output_type": "display_data",
        "metadata": {},
        "data": {
            "image/png": b64,
            "text/plain": [f"<Figure: {png_path.name}>"],
        },
    }


def build_notebook(verifier_output: str) -> None:
    """Build a multi-cell narrative notebook with pre-baked outputs.

    Re-running 'Run All' re-executes the verifier as a subprocess and re-reads the
    written artifacts; the pre-baked outputs make the notebook readable without
    executing it (e.g. on GitHub, nbviewer, or a marker's static viewer).
    """
    generated_at = datetime.now().isoformat(timespec="seconds")
    data_dir = BASE_DIR / "Task3_data"

    alerts_df = pd.read_csv(data_dir / "alert_results.csv")
    alert_grouping = (
        alerts_df.groupby(["config_applied", "alert_type"]).size().unstack(fill_value=0).astype(int)
    )
    diff_ids = ["TXN-SG-003", "TXN-SG-007", "TXN-SG-009", "TXN-US-011"]
    diff_alerts = alerts_df.loc[
        alerts_df["txn_id"].isin(diff_ids),
        ["txn_id", "config_applied", "alert_type", "reason"],
    ].reset_index(drop=True)

    fx_status = pd.read_csv(data_dir / "fx_rate_status.csv")
    sanctions_status = pd.read_csv(data_dir / "sanctions_refresh_status.csv")[
        ["source_id", "status", "refresh_mode", "cache_age_days", "record_count", "list_publish_date"]
    ]
    coverage = pd.read_csv(data_dir / "rules_ml_coverage.csv")
    sensitivity = pd.read_csv(data_dir / "sensitivity_analysis.csv")
    enforcement = pd.read_csv(data_dir / "public_enforcement_backtest.csv")[
        ["scenario_country", "jurisdiction_tested", "alert_types", "surfaced_by_tool", "limitation_note"]
    ]
    iforest_preview = pd.read_csv(data_dir / "isolation_forest_results.csv")[
        ["txn_id", "computed_structuring_us", "computed_structuring_sg", "iforest_anomaly", "rules_triggered"]
    ].head(15)

    cells: list[dict] = []

    cells.append(_md(
        "# Task 3 - Jurisdiction-Aware AML/KYC Prototype\n"
        "**JurisCom RegTech | US BSA/FinCEN vs Singapore MAS Notice 626**\n\n"
        f"_Generated by `run_all.py` at {generated_at}._\n\n"
        "This notebook is the narrative view over the verifier (`Task3_verify_notebook.py`). "
        "Each section reads an artifact that the verifier wrote into `Task3_data/` and renders it inline. "
        "Outputs below are pre-baked from the build run, so the notebook is readable without execution; "
        "running the first code cell re-executes the verifier to refresh everything.\n"
    ))

    cells.append(_md(
        "## 0. Run (or re-run) the verifier\n\n"
        "Executes `Task3_verify_notebook.py` as a subprocess. The verifier prints the differential-case, "
        "trigger-coverage, and structuring checklists, then writes all CSV/PNG evidence into `Task3_data/`.\n"
    ))
    cells.append(_code(
        "import subprocess, sys\n"
        "from pathlib import Path\n"
        "\n"
        "import pandas as pd\n"
        "from IPython.display import Image, display\n"
        "\n"
        "BASE = Path.cwd()\n"
        "DATA = BASE / \"Task3_data\"\n"
        "\n"
        "result = subprocess.run(\n"
        "    [sys.executable, str(BASE / \"Task3_verify_notebook.py\")],\n"
        "    capture_output=True, text=True,\n"
        ")\n"
        "print(result.stdout)\n"
        "if result.returncode != 0:\n"
        "    print(\"STDERR:\\n\", result.stderr)\n"
        "print(f\"verifier exit code: {result.returncode}\")\n",
        [_stream(verifier_output + "\nverifier exit code: 0\n")],
    ))

    cells.append(_md(
        "## 1. Data-source freshness\n\n"
        "Cross-jurisdiction dashboards depend on a live FX rate (Frankfurter public API into "
        "`fx_rates.json` cache) and three sanctions sources (OFAC SDN XML, UN Consolidated XML, "
        "MAS TFS landing-page scrape). The status artifacts surface staleness, maintenance windows, "
        "and JS-render limitations as first-class signals — exactly what a compliance reviewer needs.\n"
    ))
    cells.append(_code(
        "pd.read_csv(DATA / \"fx_rate_status.csv\")\n",
        [_df_output(fx_status)],
    ))
    cells.append(_code(
        "pd.read_csv(DATA / \"sanctions_refresh_status.csv\")[\n"
        "    [\"source_id\", \"status\", \"refresh_mode\", \"cache_age_days\", \"record_count\", \"list_publish_date\"]\n"
        "]\n",
        [_df_output(sanctions_status)],
    ))

    cells.append(_md(
        "## 2. Rules engine - alert distribution\n\n"
        "The same jurisdiction-agnostic engine evaluates every transaction under both US BSA/FinCEN "
        "and Singapore MAS Notice 626 configurations. Each cell of the matrix below is the count of "
        "alerts of that type produced under the corresponding jurisdiction's rules. The Singapore "
        "STR column dominates because MAS Notice 626 is risk-based with no fixed monetary threshold; "
        "the US CTR + SAR columns dominate the US side because BSA is threshold-driven.\n"
    ))
    cells.append(_code(
        "alerts = pd.read_csv(DATA / \"alert_results.csv\")\n"
        "alerts.groupby([\"config_applied\", \"alert_type\"]).size().unstack(fill_value=0).astype(int)\n",
        [_df_output(alert_grouping)],
    ))

    cells.append(_md(
        "### Four jurisdiction-differential cases\n\n"
        "These four synthetic transactions produce **opposite** compliance outcomes under each "
        "jurisdiction. They are the headline evidence that a one-size-fits-all rule engine produces "
        "systematic compliance errors at a cross-border bank.\n\n"
        "| Case | Transaction | The difference |\n"
        "|---|---|---|\n"
        "| A | `TXN-SG-003` | US CTR fires vs SG one-off CDD threshold not met |\n"
        "| B | `TXN-SG-007` | SG risk-based STR fires below the US SAR floor |\n"
        "| C | `TXN-SG-009` | SG domestic-PEP EDD fires; US has no domestic PEP rule |\n"
        "| D | `TXN-US-011` | SG reasonable-measures BO_FLAG fires; US bright-line does not |\n"
    ))
    cells.append(_code(
        "diff_ids = [\"TXN-SG-003\", \"TXN-SG-007\", \"TXN-SG-009\", \"TXN-US-011\"]\n"
        "alerts.loc[alerts[\"txn_id\"].isin(diff_ids), [\"txn_id\", \"config_applied\", \"alert_type\", \"reason\"]]\n",
        [_df_output(diff_alerts)],
    ))

    cells.append(_md(
        "### Threshold comparison chart\n\n"
        "Left panel - alert-type distribution by jurisdiction. Right panel - selected monetary "
        "thresholds (US CTR USD 10k vs SG one-off CDD SGD 20k in USD-equivalent terms), with the US "
        "SAR floor at USD 5k and Singapore's no-fixed-threshold risk-based STR called out.\n"
    ))
    cells.append(_code(
        "display(Image(str(DATA / \"threshold_comparison.png\")))\n",
        [_image_output(data_dir / "threshold_comparison.png")],
    ))

    cells.append(_md(
        "## 3. Structuring detector\n\n"
        "Computes a 7-day rolling sum per customer over cash/currency transactions strictly below the "
        "jurisdiction's reporting threshold. Flags every contributing transaction when the rolling "
        "window reaches or exceeds the threshold **and** contains at least the minimum number of "
        "transactions. Production should aggregate across related accounts, branches, and entities.\n\n"
        "The table below previews the first 15 transactions with their computed structuring flags, "
        "Isolation Forest anomaly classification, and any rules-engine triggers.\n"
    ))
    cells.append(_code(
        "iforest = pd.read_csv(DATA / \"isolation_forest_results.csv\")\n"
        "iforest[[\"txn_id\", \"computed_structuring_us\", \"computed_structuring_sg\", \"iforest_anomaly\", \"rules_triggered\"]].head(15)\n",
        [_df_output(iforest_preview)],
    ))

    cells.append(_md(
        "## 4. Public enforcement scenario back-test\n\n"
        "Public-record scenario simulation - **not** a replay of confidential historical transactions. "
        "Asks: if the risk indicators (country nexus, partial sanctions match, ownership opacity) "
        "remained visible in the transaction/customer fields, would this prototype surface the case "
        "for compliance review? Scenarios drawn from the 2019 SCB sanctions-enforcement themes "
        "(Iran, Myanmar, Syria, Sudan, Zimbabwe).\n"
    ))
    cells.append(_code(
        "pd.read_csv(DATA / \"public_enforcement_backtest.csv\")[\n"
        "    [\"scenario_country\", \"jurisdiction_tested\", \"alert_types\", \"surfaced_by_tool\", \"limitation_note\"]\n"
        "]\n",
        [_df_output(enforcement)],
    ))

    cells.append(_md(
        "## 5. Isolation Forest + SHAP anomaly layer\n\n"
        "Unsupervised review-prioritisation overlay. The compliance control is still the rules "
        "engine; ML/SHAP supports analyst triage but does not decide whether to file SARs/STRs.\n\n"
        "**Rules vs ML coverage** - how the two layers agree or diverge on the synthetic dataset. "
        "0 ML-only flags means the ML layer confirmed high-risk rule alerts rather than discovering "
        "a separate typology - the expected behaviour on a small dataset.\n"
    ))
    cells.append(_code(
        "pd.read_csv(DATA / \"rules_ml_coverage.csv\")\n",
        [_df_output(coverage)],
    ))
    cells.append(_md(
        "**Sensitivity analysis** - how alert volumes change when Isolation Forest contamination is "
        "swept from 0.05 to 0.20 and when the structuring rolling-window lookback is swept from 3 "
        "to 14 days. This is the review-volume trade-off a bank model-risk team would approve "
        "before production use.\n"
    ))
    cells.append(_code(
        "pd.read_csv(DATA / \"sensitivity_analysis.csv\")\n",
        [_df_output(sensitivity)],
    ))

    cells.append(_md(
        "### SHAP - feature importance and per-transaction waterfall\n\n"
        "The summary plot ranks features by mean absolute SHAP value across all transactions. The "
        "waterfall plot decomposes the **single most-anomalous transaction** (lowest Isolation "
        "Forest score) into the feature contributions that pushed it into the anomaly region.\n"
    ))
    cells.append(_code(
        "display(Image(str(DATA / \"shap_summary.png\")))\n",
        [_image_output(data_dir / "shap_summary.png")],
    ))
    cells.append(_code(
        "display(Image(str(DATA / \"shap_waterfall_anomaly.png\")))\n",
        [_image_output(data_dir / "shap_waterfall_anomaly.png")],
    ))

    cells.append(_md(
        "## 6. Interpretation guardrail\n\n"
        "- The **rules engine is the compliance control**. The Isolation Forest + SHAP layer is "
        "review prioritisation only and does not by itself create a filing obligation.\n"
        "- The MAS TFS scraper is **best-effort**. PDF body parsing is out of scope and remains a "
        "manual legal review step, or a licensed vendor feed (Refinitiv World-Check, Dow Jones "
        "Risk Center, ComplyAdvantage).\n"
        "- All alerts are subject to **mandatory human review** before customer-facing action.\n"
        "- Multi-jurisdiction conflict is documented, **not auto-resolved** - the precedence rule "
        "is a bank-policy choice (booking-entity-wins, most-restrictive-rule, counterparty-touches).\n"
        "- The full design rationale, model card, and trigger-logic guide are in `Task3_summary.md`, "
        "`Task3_model_card.md`, and `Task3_Flow_and_Logic.md`.\n"
    ))

    notebook = {
        "cells": cells,
        "metadata": {
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3",
            },
            "language_info": {
                "name": "python",
                "pygments_lexer": "ipython3",
            },
        },
        "nbformat": 4,
        "nbformat_minor": 5,
    }
    out = BASE_DIR / "Task3_notebook.ipynb"
    out.write_text(json.dumps(notebook, indent=2), encoding="utf-8")
    log(f"wrote {out.name} ({len(cells)} cells)")


def assert_expected_outputs() -> None:
    missing: list[str] = []
    for name in ROOT_FILES:
        if not (BASE_DIR / name).exists():
            missing.append(name)
    for name in DATA_ARTIFACTS_EXPECTED:
        if not (BASE_DIR / "Task3_data" / name).exists():
            missing.append(f"Task3_data/{name}")
    for folder in ["Task3_config", "Task3_data/sanctions_cache"]:
        if not (BASE_DIR / folder).exists():
            missing.append(folder)
    if missing:
        raise RuntimeError("Missing expected submission files: " + ", ".join(missing))


def should_zip(path: Path) -> bool:
    relative = path.relative_to(BASE_DIR)
    parts = set(relative.parts)
    if path == ZIP_PATH:
        return False
    if path.name.startswith("~$") or path.suffix.lower() == ".tmp":
        return False
    if "__pycache__" in parts or ".ipynb_checkpoints" in parts:
        return False
    return (
        path.name in ROOT_FILES
        or relative.parts[0] in {"Task3_config", "Task3_data"}
    )


def build_zip() -> None:
    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(BASE_DIR.rglob("*")):
            if path.is_file() and should_zip(path):
                zf.write(path, path.relative_to(BASE_DIR))
    log(f"wrote {ZIP_PATH.name} ({ZIP_PATH.stat().st_size:,} bytes)")


def main() -> int:
    log(f"project root: {BASE_DIR}")
    run_python("Task3_sanctions_refresh.py", capture=True)
    verifier_output = run_python("Task3_verify_notebook.py", capture=True)
    build_notebook(verifier_output)
    assert_expected_outputs()
    build_zip()
    log("complete")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
